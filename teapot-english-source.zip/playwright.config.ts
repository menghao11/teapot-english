import { defineConfig } from '@playwright/test'

export default defineConfig({
  testDir: 'e2e',
  timeout: 90_000,
  workers: 1,
  retries: 0,
  use: {
    baseURL: 'http://127.0.0.1:47221',
    viewport: { width: 1280, height: 800 },
    launchOptions: {
      args: ['--use-gl=angle', '--use-angle=swiftshader', '--ignore-gpu-blocklist', '--disable-dev-shm-usage'],
    },
  },
  webServer: {
    command: 'npm run dev',
    url: 'http://127.0.0.1:47221',
    reuseExistingServer: true,
    timeout: 120_000,
  },
})
