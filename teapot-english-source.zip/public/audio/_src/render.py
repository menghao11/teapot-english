#!/usr/bin/env python3
"""Original procedural tea-party BGM + success chime.

Warm cartoon picture-book tea party: sparse music-box and soft plucked tones,
one continuous seamless loop, plus a short success chime in the same palette.

No external samples or soundfonts. Reproducible with a fixed RNG seed.
Sample rate: 44.1 kHz.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy import signal
from scipy.ndimage import minimum_filter1d

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SR = 44100
SEED = 20261116
BPM = 80
BEATS_PER_BAR = 4
N_BARS = 16
BEAT = 60.0 / BPM          # 0.75 s
BAR = BEAT * BEATS_PER_BAR  # 3.0 s
LOOP_SECONDS = BAR * N_BARS  # 48.000 s
SAMPLES_PER_BEAT = int(round(BEAT * SR))  # 33075 exactly
LOOP_SAMPLES = SAMPLES_PER_BEAT * BEATS_PER_BAR * N_BARS  # 2116800
assert SAMPLES_PER_BEAT * 4 == int(BAR * SR)
assert LOOP_SAMPLES == 2_116_800

BGM_TARGET_LUFS = -25.0
SFX_TARGET_LUFS = -19.0
TP_CEILING = 10 ** (-1.05 / 20)  # a little under -1 dBTP

ROOT = Path(__file__).resolve().parents[1]
SRC = Path(__file__).resolve().parent
WAV_DIR = SRC / "wav"
REPORT_DIR = SRC / "reports"
WAV_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)

rng = np.random.default_rng(SEED)


def midi_hz(m: float) -> float:
    return 440.0 * (2.0 ** ((m - 69.0) / 12.0))


def sample_at(bar: int, beat: float) -> int:
    """Absolute sample index. bar and beat are 1-indexed."""
    beats = (bar - 1) * BEATS_PER_BAR + (beat - 1.0)
    return int(round(beats * SAMPLES_PER_BEAT))


def dur_samples(beats: float) -> int:
    return int(round(beats * SAMPLES_PER_BEAT))


# ---------------------------------------------------------------------------
# Tone generators (soft plucked / sine-bell music box)
# ---------------------------------------------------------------------------
def _exp_env(n: int, attack: float, decay: float, release: float | None = None) -> np.ndarray:
    t = np.arange(n) / SR
    env = np.exp(-t / max(decay, 1e-4))
    a = min(n, max(1, int(round(attack * SR))))
    env[:a] *= np.linspace(0.0, 1.0, a)
    if release is not None:
        r = min(n // 3, max(1, int(round(release * SR))))
        env[-r:] *= np.linspace(1.0, 0.0, r) ** 2
    return env


def music_box_tone(f0: float, dur: float, vel: float = 0.6) -> np.ndarray:
    """Inharmonic sine-bell tine, soft attack, long ringing decay."""
    # Longer buffer so the tine can ring past the written note length.
    ring = max(dur + 2.8, 3.2) * (440.0 / max(f0, 80.0)) ** 0.25
    n = int(round(ring * SR))
    t = np.arange(n) / SR
    # Slightly stretched partials, higher ones decay faster (music-box tine).
    partials = (
        (1.000, 1.00, 1.00),
        (2.004, 0.38, 0.62),
        (3.012, 0.14, 0.45),
        (4.028, 0.08, 0.34),
        (5.18, 0.035, 0.26),
        (6.35, 0.018, 0.20),
        (8.10, 0.010, 0.16),
    )
    # Lower notes ring longer.
    tau0 = 1.85 * (400.0 / f0) ** 0.45
    y = np.zeros(n)
    phase0 = rng.uniform(0, 2 * np.pi)
    for ratio, amp, dscale in partials:
        f = f0 * ratio
        if f > SR * 0.45:
            continue
        tau = tau0 * dscale
        ph = phase0 * (1.0 if ratio == 1.0 else rng.uniform(0, 2 * np.pi))
        # Tiny slow detune wobble, almost inaudible, avoids a dead sine.
        wobble = 1.0 + 0.0004 * np.sin(2 * np.pi * rng.uniform(0.7, 1.4) * t + ph)
        y += amp * np.exp(-t / tau) * np.sin(2 * np.pi * f * wobble * t + ph)
    # Very quiet body / wood resonance under the tine.
    body_f = np.clip(f0 * 0.5, 90.0, 280.0)
    y += 0.07 * vel * np.exp(-t / 0.22) * np.sin(2 * np.pi * body_f * t)
    env = _exp_env(n, attack=0.0035, decay=20.0, release=0.35)
    y *= env * vel
    # Soft low-pass: keep it sweet, not brittle or toy-harsh.
    cutoff = float(np.clip(4200 + f0 * 1.2, 3500, 7000))
    y = signal.sosfilt(signal.butter(2, cutoff / (SR / 2), "low", output="sos"), y)
    return y


def pluck_tone(f0: float, dur: float, vel: float = 0.3) -> np.ndarray:
    """Soft mid/low plucked string: harmonic sines + tiny noise chip."""
    ring = max(dur + 1.6, 2.0)
    n = int(round(ring * SR))
    t = np.arange(n) / SR
    tau0 = 0.95 * (220.0 / f0) ** 0.35
    partials = (
        (1, 1.00, 1.00),
        (2, 0.45, 0.55),
        (3, 0.18, 0.40),
        (4, 0.10, 0.30),
        (5, 0.05, 0.24),
        (6, 0.03, 0.20),
    )
    y = np.zeros(n)
    for k, amp, dscale in partials:
        f = f0 * k
        if f > SR * 0.45:
            continue
        ph = rng.uniform(0, 2 * np.pi)
        y += amp * np.exp(-t / (tau0 * dscale)) * np.sin(2 * np.pi * f * t + ph)
    # Nylon-like attack chip, tightly band-passed, very short.
    chip_n = min(n, int(0.012 * SR))
    chip = rng.uniform(-1, 1, chip_n)
    chip = signal.sosfilt(
        signal.butter(2, [max(f0 * 0.7, 80) / (SR / 2), min(f0 * 6, 2500) / (SR / 2)],
                      "bandpass", output="sos"),
        chip,
    )
    chip *= np.exp(-np.arange(chip_n) / SR / 0.004) * 0.18
    y[:chip_n] += chip
    env = _exp_env(n, attack=0.006, decay=20.0, release=0.28)
    y *= env * vel
    y = signal.sosfilt(signal.butter(2, 3800 / (SR / 2), "low", output="sos"), y)
    return y


def pan_stereo(mono: np.ndarray, pan: float) -> np.ndarray:
    """Equal-power pan. pan in [-1, 1], 0 is centre."""
    pan = float(np.clip(pan, -1.0, 1.0))
    angle = (pan + 1.0) * (np.pi / 4.0)
    left, right = np.cos(angle), np.sin(angle)
    out = np.zeros((len(mono), 2))
    out[:, 0] = mono * left
    out[:, 1] = mono * right
    return out


def add_at(buf: np.ndarray, sig: np.ndarray, start: int, gain: float = 1.0) -> None:
    if start >= len(buf):
        return
    if sig.ndim == 1:
        sig = sig[:, None]
    if sig.shape[1] == 1 and buf.ndim == 2:
        sig = np.repeat(sig, buf.shape[1], axis=1)
    i0 = max(0, start)
    s0 = i0 - start
    i1 = min(len(buf), start + len(sig))
    s1 = s0 + (i1 - i0)
    buf[i0:i1] += sig[s0:s1] * gain


# ---------------------------------------------------------------------------
# Arrangement — original F major / pentatonic-leaning theme, 16 bars, 80 BPM
# Sparse on purpose: leaves room for English dialogue. No drums, no voices.
# Contour is a wandering tea-table figure, not a children's sing-along.
# ---------------------------------------------------------------------------
# (bar, beat, dur_beats, midi, vel, kind, pan)
# kind: 'box' | 'pluck'
NOTES = [
    # ---- A: bars 1–4 -------------------------------------------------------
    (1, 1.0, 1.0, 69, 0.70, "box", -0.15),    # A4
    (1, 2.5, 0.5, 67, 0.48, "box", -0.05),    # G4
    (1, 3.0, 2.0, 65, 0.62, "box",  0.10),    # F4
    (2, 2.0, 1.0, 72, 0.68, "box",  0.22),    # C5
    (2, 3.0, 2.0, 69, 0.52, "box", -0.10),    # A4
    (3, 1.0, 1.5, 67, 0.58, "box", -0.08),    # G4
    (3, 2.5, 0.5, 69, 0.46, "box",  0.05),    # A4
    (3, 3.0, 2.0, 65, 0.58, "box",  0.12),    # F4
    # bar 4: rest in the melody — breathing room

    (1, 1.0, 3.0, 53, 0.34, "pluck", -0.08),  # F3
    (1, 3.0, 2.0, 60, 0.24, "pluck",  0.18),  # C4
    (2, 1.0, 3.0, 57, 0.27, "pluck",  0.06),  # A3
    (3, 1.0, 3.0, 53, 0.32, "pluck", -0.10),  # F3
    (3, 3.0, 2.0, 62, 0.20, "pluck",  0.16),  # D4
    (4, 1.0, 4.0, 48, 0.22, "pluck",  0.00),  # C3

    # ---- A': bars 5–8 ------------------------------------------------------
    (5, 1.0, 1.0, 69, 0.64, "box", -0.14),
    (5, 2.0, 1.0, 72, 0.66, "box",  0.18),
    (5, 3.0, 2.0, 74, 0.58, "box",  0.28),    # D5
    (6, 1.0, 1.5, 72, 0.62, "box",  0.16),
    (6, 2.5, 0.5, 69, 0.46, "box", -0.08),
    (6, 3.0, 2.0, 67, 0.52, "box", -0.12),
    (7, 1.0, 1.0, 65, 0.58, "box",  0.08),
    (7, 2.5, 0.5, 67, 0.42, "box", -0.04),
    (7, 3.0, 1.0, 69, 0.52, "box",  0.04),
    (7, 4.0, 1.0, 72, 0.56, "box",  0.20),
    (8, 1.0, 1.0, 74, 0.50, "box",  0.24),
    (8, 2.0, 2.0, 72, 0.48, "box",  0.10),
    # beat 4 of bar 8 left open

    (5, 1.0, 3.0, 50, 0.30, "pluck", -0.12),  # D3
    (5, 3.0, 2.0, 57, 0.22, "pluck",  0.10),
    (6, 1.0, 3.0, 48, 0.28, "pluck",  0.00),  # C3
    (6, 3.0, 2.0, 55, 0.20, "pluck",  0.14),  # G3
    (7, 1.0, 3.0, 53, 0.30, "pluck", -0.08),
    (7, 3.0, 2.0, 57, 0.20, "pluck",  0.10),
    (8, 1.0, 4.0, 48, 0.24, "pluck",  0.00),

    # ---- B: bars 9–12, a little higher, still quiet -----------------------
    (9,  1.0, 2.0, 77, 0.50, "box",  0.20),   # F5
    (9,  3.0, 1.0, 74, 0.46, "box",  0.12),
    (9,  4.0, 1.0, 72, 0.46, "box",  0.00),
    (10, 1.0, 2.0, 69, 0.52, "box", -0.10),
    (10, 3.0, 1.0, 67, 0.42, "box", -0.16),
    (11, 1.0, 1.0, 72, 0.56, "box",  0.14),
    (11, 2.5, 0.5, 69, 0.42, "box", -0.04),
    (11, 3.0, 2.0, 65, 0.52, "box",  0.08),
    (12, 1.0, 2.0, 67, 0.48, "box", -0.08),
    (12, 3.0, 1.0, 65, 0.42, "box",  0.06),

    (9,  1.0, 3.0, 53, 0.28, "pluck", -0.08),
    (9,  3.0, 2.0, 60, 0.20, "pluck",  0.16),
    (10, 1.0, 3.0, 57, 0.24, "pluck",  0.06),
    (11, 1.0, 3.0, 58, 0.26, "pluck", -0.14),  # Bb3 (IV, warm)
    (11, 3.0, 2.0, 53, 0.20, "pluck",  0.04),
    (12, 1.0, 4.0, 48, 0.24, "pluck",  0.00),

    # ---- A return: bars 13–16, settles on F so the loop can restart -------
    (13, 1.0, 1.0, 69, 0.66, "box", -0.14),
    (13, 2.5, 0.5, 67, 0.48, "box", -0.04),
    (13, 3.0, 2.0, 65, 0.60, "box",  0.10),
    (14, 2.0, 1.0, 72, 0.64, "box",  0.20),
    (14, 3.0, 2.0, 69, 0.50, "box", -0.10),
    (15, 1.0, 1.5, 67, 0.54, "box", -0.08),
    (15, 2.5, 0.5, 65, 0.42, "box",  0.04),
    (15, 3.0, 2.0, 62, 0.48, "box",  0.12),    # D4, gentle descent
    (16, 1.0, 3.0, 65, 0.54, "box",  0.00),    # F4, rings into bar 1's A4

    (13, 1.0, 3.0, 53, 0.32, "pluck", -0.08),
    (13, 3.0, 2.0, 60, 0.22, "pluck",  0.16),
    (14, 1.0, 3.0, 57, 0.26, "pluck",  0.06),
    (15, 1.0, 3.0, 48, 0.26, "pluck",  0.00),
    (15, 3.0, 2.0, 55, 0.20, "pluck",  0.12),
    (16, 1.0, 4.0, 53, 0.30, "pluck", -0.04),  # F3 pedal into the loop
]


def render_note(midi: float, vel: float, dur_beats: float, kind: str, pan: float) -> np.ndarray:
    f0 = midi_hz(midi)
    dur = dur_beats * BEAT
    if kind == "box":
        sig = music_box_tone(f0, dur, vel)
        # Slight extra width: a 4-cent detuned copy, very quiet.
        det = music_box_tone(f0 * (2 ** (4 / 1200)), dur, vel * 0.35)
        mixed = pan_stereo(sig, pan)
        other = pan_stereo(det, -pan * 0.6)
        if len(other) > len(mixed):
            tmp = np.zeros((len(other), 2))
            tmp[:len(mixed)] = mixed
            mixed = tmp
        mixed[:len(other)] += other * 0.45
        return mixed
    return pan_stereo(pluck_tone(f0, dur, vel), pan)


def realized_notes():
    """Freeze jitter/velocity once so all three passes are identical."""
    out = []
    for bar, beat, dur_beats, midi, vel, kind, pan in NOTES:
        jitter = int(round(rng.uniform(-0.004, 0.004) * SR))
        v = vel * float(rng.uniform(0.96, 1.04))
        out.append((bar, beat, dur_beats, midi, v, kind, pan, jitter))
    return out


def render_dry_passes(n_passes: int = 3, tail_seconds: float = 4.0) -> np.ndarray:
    """Place the arrangement n times in one buffer so dry tine/pluck tails
    from the end of a pass continue into the next pass (no clipped join)."""
    tail = int(round(tail_seconds * SR))
    buf = np.zeros((LOOP_SAMPLES * n_passes + tail, 2))
    realized = realized_notes()
    events = []
    for bar, beat, dur_beats, midi, vel, kind, pan, jitter in realized:
        tone = render_note(midi, vel, dur_beats, kind, pan)
        events.append((sample_at(bar, beat) + jitter, tone))
    for p in range(n_passes):
        off = p * LOOP_SAMPLES
        for start, tone in events:
            add_at(buf, tone, off + start, 1.0)
    return buf


# ---------------------------------------------------------------------------
# Warm room reverb (Schroeder/Freeverb-style comb + allpass, stereo)
# ---------------------------------------------------------------------------
def _comb(x: np.ndarray, delay: int, feedback: float) -> np.ndarray:
    b = np.zeros(delay + 1)
    a = np.zeros(delay + 1)
    b[0] = 1.0
    a[0] = 1.0
    a[delay] = -feedback
    return signal.lfilter(b, a, x)


def _allpass(x: np.ndarray, delay: int, g: float = 0.6) -> np.ndarray:
    b = np.zeros(delay + 1)
    a = np.zeros(delay + 1)
    b[0] = -g
    b[delay] = 1.0
    a[0] = 1.0
    a[delay] = -g
    return signal.lfilter(b, a, x)


def schroeder_reverb(
    x: np.ndarray,
    wet: float = 0.24,
    rt60: float = 1.45,
    predelay: float = 0.016,
) -> np.ndarray:
    """Causal stereo reverb. Apply to a 3-pass render, then cut the middle."""
    if x.ndim == 1:
        x = np.stack([x, x], axis=1)
    n, ch = x.shape
    pre = int(round(predelay * SR))
    delayed = np.vstack([np.zeros((pre, ch)), x])  # longer by predelay

    # Freeverb-ish comb lengths at 44.1 kHz, slightly different per side.
    comb_l = (1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    comb_r = (1139, 1211, 1300, 1379, 1445, 1514, 1580, 1640)
    ap_l = (556, 441, 341, 225)
    ap_r = (579, 464, 364, 248)

    def rt_feedback(delay_samp: int) -> float:
        # fb ** (SR / delay) ≈ 10 ** (-3 / rt60)  => fb = 10 ** (-3 * delay / (rt60 * SR))
        return 10 ** (-3.0 * delay_samp / (rt60 * SR))

    wet_l = np.zeros(len(delayed))
    wet_r = np.zeros(len(delayed))
    # Input is a mono send (sum) so the room is coherent, then split by delay.
    send = delayed.mean(axis=1)
    for d in comb_l:
        wet_l += _comb(send, d, rt_feedback(d))
    for d in comb_r:
        wet_r += _comb(send, d, rt_feedback(d))
    wet_l /= len(comb_l)
    wet_r /= len(comb_r)
    for d in ap_l:
        wet_l = _allpass(wet_l, d, 0.55)
    for d in ap_r:
        wet_r = _allpass(wet_r, d, 0.55)

    # Warm the wet signal; keep speech band a little clearer.
    sos_lp = signal.butter(2, 6200 / (SR / 2), "low", output="sos")
    sos_hp = signal.butter(1, 80 / (SR / 2), "high", output="sos")
    wet_l = signal.sosfilt(sos_hp, signal.sosfilt(sos_lp, wet_l))
    wet_r = signal.sosfilt(sos_hp, signal.sosfilt(sos_lp, wet_r))

    # Align wet with original length: predelay already at the front of `delayed`.
    # Dry stays exactly on the 3-pass grid; wet is trimmed/padded to dry length.
    wet_st = np.stack([wet_l, wet_r], axis=1)
    if len(wet_st) < n:
        wet_st = np.vstack([wet_st, np.zeros((n - len(wet_st), 2))])
    wet_st = wet_st[:n]
    return x * (1.0 - wet) + wet_st * wet * 1.15


def render_loop_seamless() -> np.ndarray:
    """Three-pass arrangement, reverb on the whole, keep the middle pass."""
    dry = render_dry_passes(n_passes=3, tail_seconds=4.0)
    wet = schroeder_reverb(dry, wet=0.25, rt60=1.45, predelay=0.016)
    mid = wet[LOOP_SAMPLES: 2 * LOOP_SAMPLES].copy()
    assert len(mid) == LOOP_SAMPLES
    # Mild presence dip so spoken English has a little more room (1–2.5 kHz).
    mid = presence_dip(mid, f=1800.0, q=0.7, gain_db=-1.8)
    return mid


def presence_dip(x: np.ndarray, f: float, q: float, gain_db: float) -> np.ndarray:
    w0 = 2 * np.pi * f / SR
    A = 10 ** (gain_db / 40)
    alpha = np.sin(w0) / (2 * q)
    b0 = 1 + alpha / A
    b1 = -2 * np.cos(w0)
    b2 = 1 - alpha / A
    a0 = 1 + alpha * A
    a1 = -2 * np.cos(w0)
    a2 = 1 - alpha * A
    b = np.array([b0, b1, b2]) / a0
    a = np.array([1.0, a1 / a0, a2 / a0])
    return signal.lfilter(b, a, x, axis=0)


def render_success() -> np.ndarray:
    """Soft ascending F-major chime in the same music-box palette. One-shot."""
    # Rolled F5–A5–C6 with a very soft F6 sparkle. Same room as the BGM.
    sequence = (
        (0.000, 77, 0.52, -0.12),  # F5
        (0.090, 81, 0.50,  0.04),  # A5
        (0.180, 84, 0.48,  0.16),  # C6
        (0.280, 89, 0.28,  0.08),  # F6, quieter sparkle
    )
    # Render into a longer buffer, reverb, then trim to 0.5–1.2 s.
    buf = np.zeros((int(3.0 * SR), 2))
    for t, midi, vel, pan in sequence:
        start = int(round(t * SR))
        tone = music_box_tone(midi_hz(midi), 1.1, vel)
        add_at(buf, pan_stereo(tone, pan), start, 1.0)
    # Same reverb character, a touch less wet so the tail fits in ~1 s.
    wet = schroeder_reverb(buf, wet=0.20, rt60=1.15, predelay=0.012)
    # Keep about 1.05–1.15 s including a natural decay; fade only the last 80 ms.
    n = int(round(1.10 * SR))
    y = wet[:n].copy()
    fade = int(0.08 * SR)
    ramp = np.linspace(1.0, 0.0, fade) ** 2
    y[-fade:] *= ramp[:, None]
    # Tiny start fade to avoid a click; attack stays soft, not startling.
    fi = int(0.004 * SR)
    y[:fi] *= np.linspace(0.0, 1.0, fi)[:, None]
    return y


# ---------------------------------------------------------------------------
# Loudness, true-peak, loop-safe limiter (no edge fade)
# ---------------------------------------------------------------------------
def kweight(x: np.ndarray) -> np.ndarray:
    # ITU-R BS.1770 pre-filter + RLB high-pass at 44.1 kHz.
    b1, a1 = [1.53090959, -2.65116903, 1.16916686], [1.0, -1.66375011, 0.71265753]
    b2, a2 = [1.0, -2.0, 1.0], [1.0, -1.98998199, 0.99000150]
    return signal.lfilter(b2, a2, signal.lfilter(b1, a1, x, axis=0), axis=0)


def _ms(x: np.ndarray) -> np.ndarray:
    y = kweight(x)
    return (y ** 2) if y.ndim == 1 else (y ** 2).sum(axis=1)


def loudness_integrated(x: np.ndarray) -> float:
    p = _ms(x)
    w, h = int(0.4 * SR), int(0.1 * SR)
    if len(p) < w:
        p = np.pad(p, (0, w - len(p)))
    blocks = np.array([p[i:i + w].mean() for i in range(0, len(p) - w + 1, h)])
    L = -0.691 + 10 * np.log10(blocks + 1e-12)
    g = blocks[L > -70]
    if len(g) == 0:
        return -70.0
    rel = -0.691 + 10 * np.log10(g.mean()) - 10
    g2 = blocks[(L > -70) & (L > rel)]
    if len(g2) == 0:
        g2 = g
    return float(-0.691 + 10 * np.log10(g2.mean()))


def loudness_max_momentary(x: np.ndarray) -> float:
    p = _ms(x)
    w = int(0.4 * SR)
    if len(p) < w:
        p = np.pad(p, (0, w - len(p)))
    cs = np.concatenate([[0], np.cumsum(p)])
    c = (cs[w:] - cs[:-w]) / w
    return float(-0.691 + 10 * np.log10(c.max() + 1e-12))


def true_peak(x: np.ndarray) -> float:
    if x.ndim == 1:
        y = signal.resample_poly(x, 4, 1)
        return float(np.max(np.abs(y)))
    return float(max(np.max(np.abs(signal.resample_poly(x[:, c], 4, 1))) for c in range(x.shape[1])))


def circular_hp(x: np.ndarray, f: float = 25.0) -> np.ndarray:
    n = len(x)
    freq = np.fft.rfftfreq(n, 1 / SR)
    h = 1 / np.sqrt(1 + (f / np.maximum(freq, 1e-12)) ** 4)
    h[0] = 0.0
    if x.ndim == 1:
        return np.fft.irfft(np.fft.rfft(x) * h, n=n)
    return np.fft.irfft(np.fft.rfft(x, axis=0) * h[:, None], n=n, axis=0)


def limiter(x: np.ndarray, ceiling: float = 0.85, look: float = 0.004, rel: float = 0.12) -> np.ndarray:
    a = np.abs(x) if x.ndim == 1 else np.abs(x).max(axis=1)
    g = np.minimum(1.0, ceiling / (a + 1e-12))
    L = int(look * SR) * 2 + 1
    g = minimum_filter1d(g, L)
    k = np.exp(-1 / (rel * SR))
    out = np.empty_like(g)
    s = 1.0
    for i, v in enumerate(g):
        s = v if v < s else v + (s - v) * k
        out[i] = s
    out = np.convolve(out, np.ones(L) / L, "same")
    out = np.minimum(out, g)
    return x * (out if x.ndim == 1 else out[:, None])


def limit_loop(x: np.ndarray, ceiling: float = 0.85, rel: float = 0.15, look: float = 0.004) -> np.ndarray:
    """Wrap-around limiter so a seamless loop does not get an edge fade."""
    pad = int(max(1.0, rel * 6) * SR)
    t = np.concatenate([x[-pad:], x, x[:pad]], axis=0)
    y = limiter(t, ceiling=ceiling, look=look, rel=rel)
    return y[pad:pad + len(x)]


def finalize_loop(x: np.ndarray, target: float) -> np.ndarray:
    x = np.asarray(x, float)
    x = circular_hp(x, 25.0)
    # Peak-normalize a little first so the first LUFS estimate is sane.
    x = x / (np.max(np.abs(x)) + 1e-12) * 0.3
    for _ in range(6):
        cur = loudness_integrated(x)
        x = x * (10 ** ((target - cur) / 20.0))
        x = limit_loop(x, ceiling=TP_CEILING)
        tp = true_peak(x)
        if tp > TP_CEILING:
            x = x * (TP_CEILING / tp)
            x = limit_loop(x, ceiling=TP_CEILING)
    # Final circular HP in case the limiter introduced a tiny DC offset.
    x = circular_hp(x, 25.0)
    tp = true_peak(x)
    if tp > TP_CEILING:
        x = x * (TP_CEILING / tp)
    return x


def finalize_sfx(x: np.ndarray, target: float) -> np.ndarray:
    x = np.asarray(x, float)
    x = x - np.mean(x, axis=0)
    x = x / (np.max(np.abs(x)) + 1e-12) * 0.3
    for _ in range(6):
        # Short one-shot: use the louder of integrated / max-momentary as the
        # control, so it lands near -19 LUFS without a startling peak.
        integ = loudness_integrated(x)
        mom = loudness_max_momentary(x)
        cur = max(integ, mom)
        x = x * (10 ** ((target - cur) / 20.0))
        x = limiter(x, ceiling=TP_CEILING, rel=0.10)
        tp = true_peak(x)
        if tp > TP_CEILING:
            x = x * (TP_CEILING / tp)
    return x


# ---------------------------------------------------------------------------
# Encode + inspect
# ---------------------------------------------------------------------------
def write_master(name: str, x: np.ndarray) -> Path:
    path = WAV_DIR / f"{name}.wav"
    sf.write(path, x, SR, subtype="PCM_24")
    return path


def write_delivery_wav(name: str, x: np.ndarray) -> Path:
    # 16-bit WAV for practical web delivery (same length as the 24-bit master).
    path = ROOT / f"{name}.wav"
    sf.write(path, x, SR, subtype="PCM_16")
    return path


def encode(name: str, wav_master: Path) -> dict[str, Path]:
    paths = {
        "wav16": ROOT / f"{name}.wav",
        "mp3": ROOT / f"{name}.mp3",
        "ogg": ROOT / f"{name}.ogg",
        "m4a": ROOT / f"{name}.m4a",
    }
    # Small but clean bitrates for a sparse music-box texture.
    cmds = {
        "mp3": [
            "ffmpeg", "-y", "-i", str(wav_master),
            "-codec:a", "libmp3lame", "-b:a", "128k", "-ar", "44100",
            "-write_xing", "1", str(paths["mp3"]),
        ],
        "ogg": [
            "ffmpeg", "-y", "-i", str(wav_master),
            "-codec:a", "libvorbis", "-q:a", "4", "-ar", "44100",
            str(paths["ogg"]),
        ],
        "m4a": [
            "ffmpeg", "-y", "-i", str(wav_master),
            "-codec:a", "aac", "-b:a", "128k", "-ar", "44100",
            "-movflags", "+faststart",
            str(paths["m4a"]),
        ],
    }
    for key, cmd in cmds.items():
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"ffmpeg {key} failed for {name}: {r.stderr[-2000:]}")
    return paths


def ffprobe_info(path: Path) -> dict:
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration,bit_rate,format_name,size:stream=codec_name,sample_rate,channels,duration,nb_samples,bits_per_sample",
        "-of", "json", str(path),
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, check=True)
    return json.loads(r.stdout)


def decode_f32(path: Path) -> np.ndarray:
    r = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(path), "-f", "f32le", "-acodec", "pcm_f32le", "-"],
        capture_output=True, check=True,
    )
    y = np.frombuffer(r.stdout, dtype=np.float32)
    # Probe channel count.
    info = ffprobe_info(path)
    ch = int(info["streams"][0].get("channels") or 2)
    if ch > 1:
        y = y.reshape(-1, ch)
    return y


def ebur128(path: Path) -> dict:
    r = subprocess.run(
        ["ffmpeg", "-nostats", "-i", str(path), "-filter_complex", "ebur128=peak=true", "-f", "null", "-"],
        capture_output=True, text=True,
    )
    # Summary is on stderr.
    text = r.stderr
    out = {"raw": text[-2500:]}
    # Parse the last "Integrated loudness", "True peak", "LRA" in the summary.
    import re
    def last(pattern):
        ms = re.findall(pattern, text)
        return ms[-1] if ms else None
    integ = last(r"I:\s+([+-]?\d+\.\d+)\s+LUFS")
    tp = last(r"Peak:\s+([+-]?\d+\.\d+)\s+dBFS")
    # True peak line looks like: "Peak:   -1.2 dBFS" under "True peak:"
    # More reliable: the "True peak:" section. Fall back to Peak after "True peak".
    tp_block = re.findall(r"True peak:\s+Peak:\s+([+-]inf|[+-]?\d+\.\d+)\s+dBFS", text)
    lra = last(r"LRA:\s+([+-]?\d+\.\d+)\s+LU")
    out["integrated_lufs"] = float(integ) if integ else None
    out["true_peak_dbtp"] = float(tp_block[-1]) if tp_block and tp_block[-1] != "-inf" else (float(tp) if tp else None)
    out["lra"] = float(lra) if lra else None
    return out


def guard_encoded_peak(name: str, master: np.ndarray, paths: dict[str, Path], is_loop: bool) -> np.ndarray:
    """If a lossy encode overshoots -1 dBTP, pull the master down and re-encode."""
    x = master
    for _ in range(4):
        overflow = False
        for key in ("mp3", "ogg", "m4a"):
            y = decode_f32(paths[key])
            # Measure true peak on the decoded musical region (trim encoder pad
            # at the end only for the check by comparing to intended length).
            n = min(len(y), len(x))
            tp = true_peak(y[:n])
            if tp > 10 ** (-1.0 / 20):
                overflow = True
                break
        if not overflow:
            return x
        x = x * (0.89 / max(tp, 1e-9))
        if is_loop:
            x = limit_loop(x, ceiling=TP_CEILING)
            x = circular_hp(x, 25.0)
        write_master(name, x)
        write_delivery_wav(name, x)
        encode(name, WAV_DIR / f"{name}.wav")
    return x


def seam_check(x: np.ndarray) -> dict:
    """Instrument-only wrap check. Does not claim anyone listened."""
    # Treat last sample then first sample as a consecutive pair.
    jump = np.abs(x[0] - x[-1])
    diffs = np.abs(np.diff(x, axis=0))
    typ = np.median(diffs)
    p99 = np.percentile(diffs, 99)
    pmax = diffs.max()
    # High-passed energy at the junction vs a typical interior bar line.
    def hp_energy_at(buf, center, win=int(0.02 * SR)):
        sl = buf[center - win:center + win]
        if len(sl) < 2:
            return 0.0
        y = signal.sosfilt(signal.butter(2, 2000 / (SR / 2), "high", output="sos"), sl, axis=0)
        return float(np.sqrt(np.mean(y ** 2)))

    wrapped = np.concatenate([x, x[: int(0.1 * SR)]], axis=0)
    seam_e = hp_energy_at(wrapped, LOOP_SAMPLES)
    # Compare with every bar line inside the loop (including 0, which is the seam
    # if we look at x alone — use bars 1..15 interiors).
    bar_e = []
    for b in range(1, N_BARS):
        bar_e.append(hp_energy_at(x, b * SAMPLES_PER_BEAT * BEATS_PER_BAR))
    # Edge RMS (first / last 50 ms) vs overall RMS — catch silence or edge fades.
    w = int(0.05 * SR)
    rms = lambda a: float(np.sqrt(np.mean(a ** 2)))
    overall = rms(x)
    head = rms(x[:w])
    tail = rms(x[-w:])
    return {
        "loop_samples": int(len(x)),
        "loop_seconds": len(x) / SR,
        "seam_abs_jump": [float(v) for v in np.atleast_1d(jump)],
        "median_step": float(np.median(typ) if np.ndim(typ) else typ),
        "p99_step": float(np.median(p99) if np.ndim(p99) else p99),
        "max_step": float(np.median(pmax) if np.ndim(pmax) else pmax),
        "seam_jump_vs_p99": float(np.max(jump) / (np.max(p99) + 1e-12)),
        "seam_highpass_rms": seam_e,
        "barline_highpass_rms_mean": float(np.mean(bar_e)),
        "barline_highpass_rms_max": float(np.max(bar_e)),
        "seam_hp_vs_barline_max": seam_e / (max(bar_e) + 1e-12),
        "rms_overall": overall,
        "rms_first_50ms": head,
        "rms_last_50ms": tail,
        "head_to_overall": head / (overall + 1e-12),
        "tail_to_overall": tail / (overall + 1e-12),
        "no_leading_silence": head > overall * 0.05,
        "no_trailing_silence": tail > overall * 0.02,  # tails may be quieter
        "first_sample": [float(v) for v in np.atleast_1d(x[0])],
        "last_sample": [float(v) for v in np.atleast_1d(x[-1])],
    }


def file_size(path: Path) -> int:
    return path.stat().st_size


def summarize_file(path: Path, intended_samples: int | None = None) -> dict:
    info = ffprobe_info(path)
    stream = info["streams"][0]
    fmt = info["format"]
    decoded = decode_f32(path)
    decoded_n = len(decoded)
    pad_end = None
    pad_start = None
    if intended_samples is not None:
        pad_end = decoded_n - intended_samples
        # Encoder delay at the start: compare first musical samples? For WAV, 0.
        # We report decoded length vs intended; for MP3/M4A the extra is typically
        # padding at both ends. Measure leading near-silence vs master later.
    ebu = ebur128(path)
    return {
        "path": str(path),
        "size_bytes": file_size(path),
        "ffprobe_duration": float(fmt.get("duration") or stream.get("duration") or 0),
        "ffprobe_codec": stream.get("codec_name"),
        "ffprobe_format": fmt.get("format_name"),
        "ffprobe_sample_rate": int(float(stream.get("sample_rate") or 0)),
        "ffprobe_channels": int(stream.get("channels") or 0),
        "ffprobe_bit_rate": int(float(fmt.get("bit_rate") or 0)),
        "ffprobe_nb_samples": stream.get("nb_samples"),
        "decoded_samples": decoded_n,
        "decoded_seconds": decoded_n / SR,
        "intended_samples": intended_samples,
        "decoded_minus_intended": (decoded_n - intended_samples) if intended_samples else 0,
        "ebur128_integrated_lufs": ebu.get("integrated_lufs"),
        "ebur128_true_peak_dbtp": ebu.get("true_peak_dbtp"),
        "ebur128_lra": ebu.get("lra"),
        "decoded_true_peak_dbtp": 20 * np.log10(true_peak(decoded) + 1e-12),
        "decoded_integrated_lufs": loudness_integrated(decoded),
        "decoded_max_momentary_lufs": loudness_max_momentary(decoded),
    }


def main() -> int:
    print(f"Rendering dry+wet loop: {BPM} BPM, {N_BARS} bars, {LOOP_SECONDS:.3f}s, {LOOP_SAMPLES} samples")
    bgm = render_loop_seamless()
    print("  dry/wet done, normalizing BGM…")
    bgm = finalize_loop(bgm, BGM_TARGET_LUFS)
    assert len(bgm) == LOOP_SAMPLES, (len(bgm), LOOP_SAMPLES)

    print("  rendering success chime…")
    sfx = finalize_sfx(render_success(), SFX_TARGET_LUFS)

    bgm_master = write_master("bgm_teaparty", bgm)
    sfx_master = write_master("sfx_success", sfx)
    write_delivery_wav("bgm_teaparty", bgm)
    write_delivery_wav("sfx_success", sfx)
    print("  encoding BGM…")
    bgm_paths = encode("bgm_teaparty", bgm_master)
    print("  encoding success…")
    sfx_paths = encode("sfx_success", sfx_master)
    bgm = guard_encoded_peak("bgm_teaparty", bgm, {**bgm_paths, "wav16": ROOT / "bgm_teaparty.wav"}, is_loop=True)
    sfx = guard_encoded_peak("sfx_success", sfx, {**sfx_paths, "wav16": ROOT / "sfx_success.wav"}, is_loop=False)
    # Re-read masters after any guard rewrite.
    bgm, _ = sf.read(WAV_DIR / "bgm_teaparty.wav", always_2d=True)
    sfx, _ = sf.read(WAV_DIR / "sfx_success.wav", always_2d=True)

    seam = seam_check(bgm)
    report = {
        "bpm": BPM,
        "key": "F major (pentatonic-leaning)",
        "bars": N_BARS,
        "meter": "4/4",
        "sr": SR,
        "loop_samples": LOOP_SAMPLES,
        "loop_seconds": LOOP_SAMPLES / SR,
        "bgm_internal_lufs": loudness_integrated(bgm),
        "bgm_internal_momentary": loudness_max_momentary(bgm),
        "bgm_internal_tp_dbtp": 20 * np.log10(true_peak(bgm) + 1e-12),
        "sfx_samples": int(len(sfx)),
        "sfx_seconds": len(sfx) / SR,
        "sfx_internal_lufs": loudness_integrated(sfx),
        "sfx_internal_momentary": loudness_max_momentary(sfx),
        "sfx_internal_tp_dbtp": 20 * np.log10(true_peak(sfx) + 1e-12),
        "seam": seam,
        "bgm_files": {},
        "sfx_files": {},
    }
    for label, path in [
        ("master24", WAV_DIR / "bgm_teaparty.wav"),
        ("wav16", ROOT / "bgm_teaparty.wav"),
        ("mp3", ROOT / "bgm_teaparty.mp3"),
        ("ogg", ROOT / "bgm_teaparty.ogg"),
        ("m4a", ROOT / "bgm_teaparty.m4a"),
    ]:
        print(f"  measuring {path.name}…")
        report["bgm_files"][label] = summarize_file(path, LOOP_SAMPLES)
    for label, path in [
        ("master24", WAV_DIR / "sfx_success.wav"),
        ("wav16", ROOT / "sfx_success.wav"),
        ("mp3", ROOT / "sfx_success.mp3"),
        ("ogg", ROOT / "sfx_success.ogg"),
        ("m4a", ROOT / "sfx_success.m4a"),
    ]:
        print(f"  measuring {path.name}…")
        report["sfx_files"][label] = summarize_file(path, len(sfx))

    out_json = REPORT_DIR / "check.json"
    with out_json.open("w") as f:
        json.dump(report, f, indent=2)
        f.write("\n")
    print(f"Wrote {out_json}")
    print(json.dumps({k: report[k] for k in report if k not in ("bgm_files", "sfx_files", "seam")}, indent=2))
    print("SEAM", json.dumps(seam, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
