# Audio drop-in

Place the original files here (or in `src/assets/audio/`):

- bgm_teaparty.ogg
- bgm_teaparty.m4a
- sfx_success.ogg
- sfx_success.m4a

The player decodes whichever the browser accepts, loops 0–48.0 seconds, and does not trim the start to hide AAC tail padding.
