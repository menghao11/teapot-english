import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import { viteSingleFile } from 'vite-plugin-singlefile'

export default defineConfig(({ command }) => ({
  base: './',
  plugins: [react(), ...(command === 'build' ? [viteSingleFile()] : [])],
  server: { host: '0.0.0.0', port: 47221, strictPort: true },
  preview: { host: '0.0.0.0', port: 47221, strictPort: true },
}))
