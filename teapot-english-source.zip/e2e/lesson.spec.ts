import { expect, test, type Page } from '@playwright/test'
import { mkdir } from 'node:fs/promises'

const lines = [
  'Hello, little cup!',
  'Hello! Is it tea time?',
  'Yes! Here is your tea.',
  'Thank you! I feel warm.',
  'Tea is better with a friend.',
  "That's you!",
]

async function mockVoice(page: Page) {
  await page.addInitScript(() => {
    const synth = {
      speaking: false,
      pending: false,
      paused: false,
      getVoices: () => [{ name: 'Test US', lang: 'en-US', default: true, localService: true, voiceURI: 'test' }],
      addEventListener: (_name: string, fn: () => void) => {
        setTimeout(fn, 0)
      },
      removeEventListener: () => {},
      cancel() {},
      resume() {},
      speak(utterance: { onend?: () => void }) {
        setTimeout(() => utterance.onend?.(), 20)
      },
    }
    Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: synth })
  })
}

function watchErrors(page: Page) {
  const errors: string[] = []
  const ignore = /favicon|bgm_teaparty|sfx_success|Failed to load resource|SpeechSynthesisVoice/i
  page.on('pageerror', (error) => {
    const text = String(error)
    if (!ignore.test(text)) errors.push(text)
  })
  page.on('console', (msg) => {
    if (msg.type() !== 'error') return
    const text = msg.text()
    if (ignore.test(text)) return
    errors.push(text)
  })
  return errors
}

test('wrong letters stay, then the tea party can be played to the end', async ({ page }) => {
  const errors = watchErrors(page)
  await mockVoice(page)
  await page.goto('/?pace=manual')
  await expect(page.getByTestId('start')).toBeVisible()
  await mkdir('/opt/cursor/artifacts', { recursive: true })
  await page.waitForTimeout(600)
  await page.screenshot({ path: '/opt/cursor/artifacts/01-invite.png' })
  await page.getByTestId('start').click()
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'puzzle')
  await expect(page.locator('#app')).toHaveAttribute('data-audio', 'ready', { timeout: 8000 })
  const decoded = await page.evaluate(async () => {
    const res = await fetch(new URL('audio/bgm_teaparty.ogg', window.location.href).toString())
    const ctx = new AudioContext()
    const audio = await ctx.decodeAudioData(await res.arrayBuffer())
    await ctx.close()
    return { duration: audio.duration, rate: audio.sampleRate, channels: audio.numberOfChannels }
  })
  expect(decoded.rate).toBe(44100)
  expect(decoded.channels).toBe(2)
  expect(decoded.duration).toBeGreaterThan(47.9)
  expect(decoded.duration).toBeLessThan(48.05)

  await page.getByTestId('tile-i').click()
  await page.getByTestId('tile-u').click()
  await page.getByTestId('check').click()
  await expect(page.getByTestId('slot-0')).toHaveText('i')
  await expect(page.getByTestId('slot-1')).toHaveText('u')
  await expect(page.getByTestId('feedback')).toContainText('还不对')
  await page.waitForTimeout(450)
  const anim = await page.getByTestId('slot-0').evaluate((el) => getComputedStyle(el).animationName)
  expect(anim === 'none' || anim === '').toBeTruthy()
  await page.getByTestId('check').click()
  await expect(page.getByTestId('hint')).toContainText('e')

  await page.getByTestId('backspace').click()
  await page.getByTestId('backspace').click()
  await expect(page.getByTestId('tile-i')).toBeEnabled()
  await expect(page.getByTestId('tile-u')).toBeEnabled()

  await page.getByTestId('tile-e').click()
  await page.getByTestId('tile-o').click()
  await page.getByTestId('check').dblclick()
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'awaken')
  await expect(page.getByTestId('caption-en')).toHaveText('teapot')
  await page.screenshot({ path: '/opt/cursor/artifacts/02-awaken.png' })

  await page.getByTestId('continue').click()
  await expect(page.getByTestId('caption-en')).toHaveText('The teapot is on the table.', { timeout: 5000 })
  await expect(page.locator('#app')).toHaveAttribute('data-cup', '0')
  await page.screenshot({ path: '/opt/cursor/artifacts/03-sentence.png' })

  for (const line of lines) {
    await page.getByTestId('next').click()
    await expect(page.getByTestId('caption-en')).toHaveText(line)
  }
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'dialogue')
  await expect(page.locator('#app')).toHaveAttribute('data-fill', '0.7')
  await expect(page.locator('#app')).toHaveAttribute('data-hop', '0')
  await page.screenshot({ path: '/opt/cursor/artifacts/04-friends.png' })

  await page.getByTestId('back').click()
  await expect(page.getByTestId('caption-en')).toHaveText('Tea is better with a friend.')
  await page.getByTestId('next').click()
  await page.getByTestId('next').click()
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'done')
  await page.getByTestId('recall').click()
  await expect(page.getByTestId('caption-en')).toHaveText('The teapot is on the table.')
  await page.screenshot({ path: '/opt/cursor/artifacts/05-done.png' })

  await page.getByTestId('replay-story').click()
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'sentence')
  await page.getByTestId('skip').click()
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'done')
  expect(errors).toEqual([])
})

test('keyboard shares slots with tiles and music stays off', async ({ page }) => {
  const errors = watchErrors(page)
  await mockVoice(page)
  await page.goto('/?pace=manual')
  await page.getByTestId('start').click()
  await page.getByTestId('music').click()
  await expect(page.locator('#app')).toHaveAttribute('data-music', 'off')
  await page.getByTestId('keyboard').focus()
  await page.keyboard.type('e')
  await page.keyboard.type('o')
  await page.keyboard.press('Enter')
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'awaken')
  await expect(page.locator('#app')).toHaveAttribute('data-music', 'off')
  await page.getByTestId('continue').click()
  await expect(page.getByTestId('caption-en')).toHaveText('The teapot is on the table.', { timeout: 5000 })
  await expect(page.locator('#app')).toHaveAttribute('data-music', 'off')
  await page.getByTestId('voice').click()
  await expect(page.locator('#app')).toHaveAttribute('data-voice', 'off')
  expect(errors).toEqual([])
})

test('mobile targets and reduced motion still reach the story', async ({ page }) => {
  const errors = watchErrors(page)
  await mockVoice(page)
  await page.emulateMedia({ reducedMotion: 'reduce' })
  await page.setViewportSize({ width: 390, height: 844 })
  await page.goto('/?pace=manual')
  await page.getByTestId('start').click()
  const box = await page.getByTestId('tile-e').boundingBox()
  expect(box?.width ?? 0).toBeGreaterThanOrEqual(44)
  expect(box?.height ?? 0).toBeGreaterThanOrEqual(44)
  await page.screenshot({ path: '/opt/cursor/artifacts/06-mobile-puzzle.png' })
  await page.getByTestId('tile-e').click()
  await page.getByTestId('tile-o').click()
  await page.getByTestId('check').click()
  await page.getByTestId('continue').click()
  await expect(page.getByTestId('caption-en')).toHaveText('The teapot is on the table.', { timeout: 4000 })
  await page.getByTestId('next').click()
  await expect(page.locator('#app')).toHaveAttribute('data-hop', '1')
  await expect(page.locator('#app')).toHaveAttribute('data-fill', '0')
  await page.getByTestId('next').click()
  await page.getByTestId('next').click()
  await expect(page.locator('#app')).toHaveAttribute('data-fill', '0.7')
  await expect(page.locator('#app')).toHaveAttribute('data-hop', '0')
  await page.getByTestId('skip').click()
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'done')
  await page.screenshot({ path: '/opt/cursor/artifacts/07-mobile-done.png' })
  expect(errors).toEqual([])
})

test('back rewinds the pour and fixed letters are not controls', async ({ page }) => {
  await mockVoice(page)
  await page.goto('/?pace=manual')
  await page.getByTestId('start').click()
  await expect(page.getByTestId('fixed-0')).toHaveText('t')
  await expect(page.getByTestId('fixed-2')).toHaveText('a')
  await expect(page.getByTestId('fixed-3')).toHaveText('p')
  await expect(page.getByTestId('fixed-5')).toHaveText('t')
  await page.keyboard.press('e')
  await page.keyboard.press('o')
  await page.keyboard.press('Enter')
  await page.getByTestId('continue').click()
  await expect(page.getByTestId('caption-en')).toHaveText('The teapot is on the table.', { timeout: 5000 })
  await page.getByTestId('next').click()
  await expect(page.locator('#app')).toHaveAttribute('data-hop', '1')
  await page.getByTestId('next').click()
  await page.getByTestId('next').click()
  await expect(page.locator('#app')).toHaveAttribute('data-pour', '1')
  await expect(page.locator('#app')).toHaveAttribute('data-hop', '0')
  const pourFrame = await page.evaluate(() => {
    const caption = document.querySelector('.caption-wrap')?.getBoundingClientRect()
    return { captionTop: caption?.top ?? 0, height: window.innerHeight }
  })
  expect(pourFrame.captionTop).toBeGreaterThan(pourFrame.height * 0.45)
  await page.screenshot({ path: '/opt/cursor/artifacts/15-pour.png' })
  await page.getByTestId('back').click()
  await page.getByTestId('back').click()
  await expect(page.getByTestId('caption-en')).toHaveText('Hello, little cup!')
  await expect(page.locator('#app')).toHaveAttribute('data-fill', '0')
  await expect(page.locator('#app')).toHaveAttribute('data-hop', '1')
})

test('ending subtitle, success chime, IME, and speech duck stay honest', async ({ page }) => {
  const errors = watchErrors(page)
  await page.addInitScript(() => {
    const synth = {
      speaking: false,
      pending: false,
      paused: false,
      getVoices: () => [{ name: 'Test US', lang: 'en-US', default: true, localService: true, voiceURI: 'test' }],
      addEventListener: (_name: string, fn: () => void) => {
        setTimeout(fn, 0)
      },
      removeEventListener: () => {},
      cancel() {},
      resume() {},
      speak(utterance: { onend?: () => void }) {
        setTimeout(() => utterance.onend?.(), 350)
      },
    }
    Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: synth })
  })
  await page.goto('/?pace=manual')
  await page.getByTestId('start').click()
  await page.getByTestId('music').click()
  await expect(page.locator('#app')).toHaveAttribute('data-music', 'off')
  const field = page.getByTestId('keyboard')
  await field.evaluate((input) => {
    const el = input as HTMLInputElement
    el.focus()
    el.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true, data: '' }))
    el.value = '茶壶'
    el.dispatchEvent(new InputEvent('input', { bubbles: true, data: '茶壶', inputType: 'insertCompositionText' }))
  })
  await expect(page.getByTestId('slot-0')).toHaveText('')
  await field.evaluate((input) => {
    const el = input as HTMLInputElement
    el.value = 'eo'
    el.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: 'eo' }))
  })
  await expect(page.getByTestId('slot-0')).toHaveText('e')
  await expect(page.getByTestId('slot-1')).toHaveText('o')
  await expect(field).toHaveValue('')
  await page.getByTestId('check').click()
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'awaken')
  await expect(page.locator('#app')).not.toHaveAttribute('data-sfx', '0')
  await expect(page.locator('#app')).toHaveAttribute('data-duck', '1')
  await page.getByTestId('replay-word').click()
  await expect(page.locator('#app')).toHaveAttribute('data-duck', '1')
  await expect(page.getByTestId('caption-en')).toHaveText('teapot')
  await expect(page.locator('#app')).toHaveAttribute('data-duck', '0', { timeout: 2000 })
  await page.getByTestId('continue').click()
  await expect(page.getByTestId('caption-zh')).toHaveText('茶壶在桌子上。', { timeout: 5000 })
  await page.getByTestId('skip').click()
  await expect(page.locator('#app')).toHaveAttribute('data-phase', 'done')
  await expect(page.getByTestId('caption-en')).toHaveText('The teapot is on the table.')
  await expect(page.getByTestId('caption-zh')).toHaveText('茶壶在桌子上。')
  await expect(page.getByTestId('closing-note')).toHaveText('茶会好温暖。')
  expect(errors).toEqual([])
})
