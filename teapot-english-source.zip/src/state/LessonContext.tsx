import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { getAudio } from '../audio/engine'
import type { AudioStatus } from '../audio/engine'
import { cancelSpeech, getVoiceEngine, speak, watchVoices } from '../audio/speech'
import type { VoiceEngine } from '../audio/speech'
import { backspace, checkPuzzle, clearLetters, createPuzzle, placeLetter, placeTile, selectSlot } from '../lesson/logic'
import { deriveScene } from '../lesson/sceneState'
import type { SceneState } from '../lesson/sceneState'
import { teapotLesson } from '../lesson/teapotLesson'
import type { Caption, Phase, PuzzleState, SpeakerId } from '../lesson/types'

const PROGRESS_KEY = 'teaparty-progress'
const AUDIO_KEY = 'teaparty-audio'

interface AudioPrefs {
  music: boolean
  voice: boolean
}

function readPrefs(): AudioPrefs {
  try {
    const raw = localStorage.getItem(AUDIO_KEY)
    if (!raw) return { music: true, voice: true }
    const parsed = JSON.parse(raw) as Partial<AudioPrefs>
    return { music: parsed.music !== false, voice: parsed.voice !== false }
  } catch {
    return { music: true, voice: true }
  }
}

function readCompleted() {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY)
    if (!raw) return false
    const parsed = JSON.parse(raw) as { teapot?: { completed?: boolean } }
    return Boolean(parsed.teapot?.completed)
  } catch {
    return false
  }
}

interface LessonApi {
  phase: Phase
  line: number
  puzzle: PuzzleState
  scene: SceneState
  caption: Caption | null
  speaking: boolean
  speaker: SpeakerId | null
  recallOn: boolean
  completedBefore: boolean
  musicOn: boolean
  voiceOn: boolean
  audioStatus: AudioStatus
  sfxPlays: number
  ducking: boolean
  voiceEngine: VoiceEngine
  reduced: boolean
  manual: boolean
  sitDown: () => void
  pressTile: (id: string) => void
  typeLetter: (letter: string) => void
  chooseSlot: (index: number) => void
  doBackspace: () => void
  doClear: () => void
  doCheck: () => void
  listen: () => void
  replayWord: () => void
  continueStory: () => void
  next: () => void
  back: () => void
  replayLine: () => void
  skipToEnd: () => void
  toggleMusic: () => void
  toggleVoice: () => void
  toggleMotion: () => void
  practiceAgain: () => void
  replayStory: () => void
  placeRecall: () => void
}

const LessonContext = createContext<LessonApi | null>(null)

export function LessonProvider({ children }: { children: ReactNode }) {
  const audio = useMemo(() => getAudio(), [])
  const prefs = useMemo(() => readPrefs(), [])
  const manual = useMemo(() => new URLSearchParams(window.location.search).get('pace') === 'manual', [])
  const [phase, setPhase] = useState<Phase>('invite')
  const [line, setLine] = useState(0)
  const [puzzle, setPuzzle] = useState<PuzzleState>(() => createPuzzle(teapotLesson))
  const [caption, setCaption] = useState<Caption | null>(null)
  const [speaking, setSpeaking] = useState(false)
  const [speaker, setSpeaker] = useState<SpeakerId | null>(null)
  const [recallOn, setRecallOn] = useState(false)
  const [completedBefore, setCompletedBefore] = useState(() => readCompleted())
  const [musicOn, setMusicOn] = useState(prefs.music)
  const [voiceOn, setVoiceOn] = useState(prefs.voice)
  const [audioStatus, setAudioStatus] = useState<AudioStatus>(audio.status)
  const [sfxPlays, setSfxPlays] = useState(0)
  const [ducking, setDucking] = useState(false)
  const [voiceEngine, setVoiceEngine] = useState<VoiceEngine>('unknown')
  const [reduced, setReduced] = useState(() => window.matchMedia('(prefers-reduced-motion: reduce)').matches)

  const phaseRef = useRef<Phase>('invite')
  const lineRef = useRef(0)
  const puzzleRef = useRef(puzzle)
  const voiceRef = useRef(prefs.voice)
  const musicRef = useRef(prefs.music)
  const reducedRef = useRef(reduced)
  const gen = useRef(0)
  const timer = useRef<number | null>(null)
  const whirlLock = useRef(false)
  const solvedLock = useRef(false)
  const lastCheck = useRef(0)

  puzzleRef.current = puzzle
  voiceRef.current = voiceOn
  musicRef.current = musicOn
  reducedRef.current = reduced

  useEffect(
    () =>
      audio.subscribe(() => {
        setAudioStatus(audio.status)
        setSfxPlays(audio.sfxPlays)
        setDucking(audio.ducking)
      }),
    [audio],
  )
  useEffect(() => watchVoices(() => setVoiceEngine(getVoiceEngine())), [])
  useEffect(() => {
    audio.setMusic(prefs.music)
  }, [audio, prefs.music])

  function commitPhase(next: Phase) {
    phaseRef.current = next
    setPhase(next)
  }
  function commitLine(next: number) {
    lineRef.current = next
    setLine(next)
  }
  function commitPuzzle(next: PuzzleState) {
    puzzleRef.current = next
    setPuzzle(next)
  }
  function clearTimer() {
    if (timer.current !== null) window.clearTimeout(timer.current)
    timer.current = null
  }
  function schedule(mine: number, ms: number, fn: () => void) {
    clearTimer()
    if (manual) return
    timer.current = window.setTimeout(() => {
      timer.current = null
      if (gen.current !== mine) return
      fn()
    }, ms)
  }
  function persistAudio(next: AudioPrefs) {
    localStorage.setItem(AUDIO_KEY, JSON.stringify(next))
  }

  async function runSentence() {
    const mine = ++gen.current
    commitPhase('sentence')
    setSpeaker('narrator')
    setCaption({
      en: teapotLesson.sentence.en,
      zh: teapotLesson.sentence.zh,
      who: 'narrator',
    })
    setSpeaking(true)
    await speak(teapotLesson.sentence.en, { rate: 0.92, pitch: 1.04, voiceOn: voiceRef.current })
    if (gen.current !== mine) return
    setSpeaking(false)
    schedule(mine, teapotLesson.sentence.hold, () => {
      void runLine(0)
    })
  }

  async function runLine(index: number) {
    const row = teapotLesson.lines[index]
    if (!row) {
      enterDone()
      return
    }
    const mine = ++gen.current
    commitPhase('dialogue')
    commitLine(index)
    setSpeaker(row.speaker)
    setCaption({ en: row.en, zh: row.zh, who: row.speaker })
    setSpeaking(true)
    await speak(row.en, { rate: 0.94, pitch: row.pitch, voiceOn: voiceRef.current })
    if (gen.current !== mine) return
    setSpeaking(false)
    schedule(mine, row.hold, () => {
      if (index + 1 >= teapotLesson.lines.length) enterDone()
      else void runLine(index + 1)
    })
  }

  function enterDone() {
    clearTimer()
    cancelSpeech()
    setSpeaking(false)
    setSpeaker(null)
    commitLine(teapotLesson.lines.length - 1)
    commitPhase('done')
    setCaption({
      en: 'The teapot is on the table.',
      zh: '茶壶在桌子上。',
      who: 'narrator',
    })
    localStorage.setItem(PROGRESS_KEY, JSON.stringify({ teapot: { completed: true } }))
    setCompletedBefore(true)
  }

  function beginWhirl() {
    if (whirlLock.current) return
    if (phaseRef.current !== 'awaken' && phaseRef.current !== 'whirl') return
    whirlLock.current = true
    gen.current += 1
    clearTimer()
    cancelSpeech()
    setSpeaking(false)
    commitPhase('whirl')
    window.setTimeout(() => {
      whirlLock.current = false
      if (phaseRef.current !== 'whirl') return
      void runSentence()
    }, reducedRef.current ? 350 : 1200)
  }

  function beginAwaken() {
    const mine = ++gen.current
    solvedLock.current = true
    commitPhase('awaken')
    setSpeaker('teapot')
    setCaption({ en: 'teapot', zh: '茶壶', who: 'teapot' })
    audio.playSuccess()
    void (async () => {
      await new Promise((resolve) => window.setTimeout(resolve, 280))
      if (gen.current !== mine) return
      setSpeaking(true)
      await speak('teapot', { rate: 0.86, pitch: 1.16, voiceOn: voiceRef.current })
      if (gen.current !== mine) return
      setSpeaking(false)
      schedule(mine, 1500, () => beginWhirl())
    })()
  }

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (phaseRef.current !== 'puzzle') return
      const tag = (event.target as HTMLElement | null)?.tagName
      if (tag === 'INPUT' || tag === 'TEXTAREA') return
      if (event.key === 'Backspace') {
        event.preventDefault()
        commitPuzzle(backspace(puzzleRef.current))
      } else if (event.key === 'Enter') {
        event.preventDefault()
        doCheck()
      } else if (/^[a-zA-Z]$/.test(event.key)) {
        commitPuzzle(placeLetter(puzzleRef.current, event.key.toLowerCase()))
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  function doCheck() {
    if (phaseRef.current !== 'puzzle' || solvedLock.current) return
    const now = performance.now()
    if (now - lastCheck.current < 400) return
    lastCheck.current = now
    const result = checkPuzzle(teapotLesson, puzzleRef.current)
    commitPuzzle(result.puzzle)
    if (result.correct && result.puzzle.solved) beginAwaken()
  }

  const api: LessonApi = {
    phase,
    line,
    puzzle,
    scene: deriveScene(phase, line),
    caption,
    speaking,
    speaker,
    recallOn,
    completedBefore,
    musicOn,
    voiceOn,
    audioStatus,
    sfxPlays,
    ducking,
    voiceEngine,
    reduced,
    manual,
    sitDown: () => {
      if (phaseRef.current !== 'invite') return
      void audio.unlock()
      commitPhase('puzzle')
    },
    pressTile: (id) => {
      if (phaseRef.current !== 'puzzle' || solvedLock.current) return
      commitPuzzle(placeTile(puzzleRef.current, id))
    },
    typeLetter: (letter) => {
      if (phaseRef.current !== 'puzzle' || solvedLock.current) return
      commitPuzzle(placeLetter(puzzleRef.current, letter))
    },
    chooseSlot: (index) => {
      if (phaseRef.current !== 'puzzle') return
      commitPuzzle(selectSlot(puzzleRef.current, index))
    },
    doBackspace: () => {
      if (phaseRef.current !== 'puzzle') return
      commitPuzzle(backspace(puzzleRef.current))
    },
    doClear: () => {
      if (phaseRef.current !== 'puzzle') return
      commitPuzzle(clearLetters(puzzleRef.current))
    },
    doCheck,
    listen: () => {
      if (phaseRef.current !== 'puzzle') return
      const note = voiceRef.current
        ? '听一听：teapot'
        : '语音关着。字幕上的词是 teapot。'
      commitPuzzle({ ...puzzleRef.current, feedback: note, wrong: false })
      void speak('teapot', { rate: 0.82, pitch: 1.08, voiceOn: voiceRef.current })
    },
    replayWord: () => {
      if (phaseRef.current !== 'awaken') return
      const mine = ++gen.current
      clearTimer()
      setSpeaking(true)
      setSpeaker('teapot')
      void (async () => {
        await speak('teapot', { rate: 0.86, pitch: 1.16, voiceOn: voiceRef.current })
        if (gen.current !== mine) return
        setSpeaking(false)
        schedule(mine, 1600, () => beginWhirl())
      })()
    },
    continueStory: () => beginWhirl(),
    next: () => {
      clearTimer()
      cancelSpeech()
      setSpeaking(false)
      if (phaseRef.current === 'sentence') {
        void runLine(0)
        return
      }
      if (phaseRef.current === 'dialogue') {
        if (lineRef.current >= teapotLesson.lines.length - 1) enterDone()
        else void runLine(lineRef.current + 1)
      }
    },
    back: () => {
      if (phaseRef.current !== 'dialogue') return
      clearTimer()
      cancelSpeech()
      setSpeaking(false)
      if (lineRef.current <= 0) {
        void runSentence()
        return
      }
      void runLine(lineRef.current - 1)
    },
    replayLine: () => {
      clearTimer()
      cancelSpeech()
      setSpeaking(false)
      if (phaseRef.current === 'sentence') void runSentence()
      else if (phaseRef.current === 'dialogue') void runLine(lineRef.current)
    },
    skipToEnd: () => {
      if (phaseRef.current !== 'sentence' && phaseRef.current !== 'dialogue') return
      enterDone()
    },
    toggleMusic: () => {
      const next = !musicRef.current
      musicRef.current = next
      setMusicOn(next)
      audio.setMusic(next)
      persistAudio({ music: next, voice: voiceRef.current })
    },
    toggleVoice: () => {
      const next = !voiceRef.current
      voiceRef.current = next
      setVoiceOn(next)
      if (!next) {
        cancelSpeech()
        setSpeaking(false)
      }
      persistAudio({ music: musicRef.current, voice: next })
    },
    toggleMotion: () => setReduced((value) => !value),
    practiceAgain: () => {
      gen.current += 1
      clearTimer()
      cancelSpeech()
      whirlLock.current = false
      solvedLock.current = false
      setSpeaking(false)
      setSpeaker(null)
      setCaption(null)
      setRecallOn(false)
      commitLine(0)
      commitPuzzle(createPuzzle(teapotLesson))
      commitPhase('puzzle')
    },
    replayStory: () => {
      setRecallOn(false)
      void runSentence()
    },
    placeRecall: () => {
      setRecallOn(true)
      setCaption({
        en: 'The teapot is on the table.',
        zh: '茶壶在桌子上。',
        who: 'narrator',
      })
      void speak('The teapot is on the table.', { rate: 0.92, pitch: 1.05, voiceOn: voiceRef.current })
    },
  }

  return <LessonContext.Provider value={api}>{children}</LessonContext.Provider>
}

export function useLesson() {
  const value = useContext(LessonContext)
  if (!value) throw new Error('useLesson outside provider')
  return value
}
