import { Component } from 'react'
import type { ReactNode } from 'react'
import { Canvas } from '@react-three/fiber'
import * as THREE from 'three'
import { LessonProvider, useLesson } from './state/LessonContext'
import { TeaWorld } from './scene/TeaWorld'
import { Hud } from './ui/Hud'
import { Whirlpool } from './ui/Whirlpool'

class SceneBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  render() {
    if (this.state.failed) {
      return <div className="gl-fallback">立体茶室没有启动。字母和故事仍然可以继续。</div>
    }
    return this.props.children
  }
}

function Shell() {
  const lesson = useLesson()
  return (
    <div
      id="app"
      data-phase={lesson.phase}
      data-line={lesson.line}
      data-cup={lesson.scene.cupVisible ? '1' : '0'}
      data-fill={lesson.scene.fill}
      data-hop={lesson.scene.hop ? '1' : '0'}
      data-pour={lesson.scene.pour ? '1' : '0'}
      data-music={lesson.musicOn ? 'on' : 'off'}
      data-voice={lesson.voiceOn ? 'on' : 'off'}
      data-reduced={lesson.reduced ? '1' : '0'}
      data-audio={lesson.audioStatus}
      data-sfx={lesson.sfxPlays}
      data-duck={lesson.ducking ? '1' : '0'}
      data-voice-engine={lesson.voiceEngine}
      data-renderer="hybrid-2.5d"
      data-manual={lesson.manual ? '1' : '0'}
    >
      <SceneBoundary>
        <Canvas
          className="webgl"
          shadows
          dpr={[1, 1.6]}
          camera={{ fov: 42, near: 0.08, far: 60, position: [0.16, 1.28, 2.45] }}
          gl={{ antialias: true, alpha: false, stencil: false }}
          onCreated={({ gl }) => {
            gl.toneMapping = THREE.ACESFilmicToneMapping
            gl.toneMappingExposure = 1.05
            gl.setClearColor('#f6d7b8')
          }}
        >
          <TeaWorld />
        </Canvas>
      </SceneBoundary>
      <div className="vignette" />
      <Hud />
      {lesson.phase === 'whirl' && <Whirlpool reduced={lesson.reduced} />}
    </div>
  )
}

export function App() {
  return (
    <LessonProvider>
      <Shell />
    </LessonProvider>
  )
}
