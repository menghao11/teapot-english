export function Whirlpool({ reduced }: { reduced: boolean }) {
  return (
    <div className={reduced ? 'whirl is-reduced' : 'whirl'} aria-hidden="true">
      {reduced ? null : (
        <svg viewBox="0 0 200 200">
          <defs>
            <linearGradient id="teaRibbon" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#f6d7a4" stopOpacity="0.95" />
              <stop offset="48%" stopColor="#e39a4e" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#9fd0c6" stopOpacity="0.55" />
            </linearGradient>
          </defs>
          {[0, 1, 2, 3].map((index) => (
            <path
              key={index}
              d={ribbon(index)}
              fill="none"
              stroke="url(#teaRibbon)"
              strokeWidth={7 - index}
              strokeLinecap="round"
              className={`ribbon ribbon-${index}`}
            />
          ))}
        </svg>
      )}
    </div>
  )
}

function ribbon(index: number) {
  const start = index * 0.7
  let d = ''
  for (let step = 0; step <= 26; step += 1) {
    const t = step / 26
    const angle = start + t * 2.15
    const radius = 88 - t * 64
    const x = 100 + Math.cos(angle) * radius
    const y = 100 + Math.sin(angle) * radius * 0.7
    d += step === 0 ? `M ${x.toFixed(1)} ${y.toFixed(1)}` : ` L ${x.toFixed(1)} ${y.toFixed(1)}`
  }
  return d
}
