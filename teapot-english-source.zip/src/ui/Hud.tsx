import { useRef } from 'react'
import { patternCells, teapotLesson } from '../lesson/teapotLesson'
import { useLesson } from '../state/LessonContext'

function LetterInput({
  onLetter,
  onBackspace,
  onCheck,
}: {
  onLetter: (letter: string) => void
  onBackspace: () => void
  onCheck: () => void
}) {
  const composing = useRef(false)
  return (
    <input
      data-testid="keyboard"
      aria-label="用键盘输入字母"
      autoCapitalize="none"
      autoCorrect="off"
      spellCheck={false}
      inputMode="text"
      onCompositionStart={() => {
        composing.current = true
      }}
      onCompositionEnd={(event) => {
        composing.current = false
        const text = event.currentTarget.value
        event.currentTarget.value = ''
        for (const ch of text.toLowerCase()) {
          if (/[a-z]/.test(ch)) onLetter(ch)
        }
      }}
      onChange={(event) => {
        if (composing.current) return
        const letter = event.target.value.slice(-1).toLowerCase()
        event.target.value = ''
        if (/^[a-z]$/.test(letter)) onLetter(letter)
      }}
      onKeyDown={(event) => {
        if (event.nativeEvent.isComposing || composing.current) return
        if (event.key === 'Backspace') {
          event.preventDefault()
          onBackspace()
        }
        if (event.key === 'Enter') {
          event.preventDefault()
          onCheck()
        }
      }}
    />
  )
}

const cells = patternCells(teapotLesson)

export function Hud() {
  const lesson = useLesson()
  const {
    phase,
    puzzle,
    caption,
    line,
    recallOn,
    completedBefore,
    musicOn,
    voiceOn,
    audioStatus,
    voiceEngine,
    reduced,
    speaking,
  } = lesson

  return (
    <div className="hud">
      <header className="topbar">
        <p className="brand">茶壶茶会</p>
        <div className="toggles">
          <button
            type="button"
            className="btn tiny"
            data-testid="music"
            aria-pressed={musicOn}
            aria-label={musicOn ? '关闭背景音乐' : '打开背景音乐'}
            onClick={lesson.toggleMusic}
          >
            {musicOn ? '音乐开' : '音乐关'}
          </button>
          <button
            type="button"
            className="btn tiny"
            data-testid="voice"
            aria-pressed={voiceOn}
            onClick={lesson.toggleVoice}
          >
            {voiceOn ? '语音开' : '语音关'}
          </button>
          <button
            type="button"
            className="btn tiny"
            data-testid="motion"
            aria-pressed={reduced}
            onClick={lesson.toggleMotion}
          >
            {reduced ? '动效简' : '动效开'}
          </button>
        </div>
      </header>

      {voiceEngine === 'missing' && (
        <p className="voice-note" data-testid="voice-fallback">
          没有找到英语语音。台词会留在字幕上。这里用的是浏览器朗读，不是录好的声音。
        </p>
      )}
      {audioStatus === 'missing' && phase !== 'invite' && (
        <p className="voice-note" data-testid="music-fallback">
          茶会音乐文件没有载入，这会儿先安静坐着。
        </p>
      )}

      <p className="sr-only" aria-live="polite">
        {phase === 'whirl' ? '茶水漾开，故事要开始了。' : ''}
      </p>

      {phase === 'invite' && (
        <section className="place-card">
          <p className="eyebrow">下午茶</p>
          <h1>坐下来吧</h1>
          <p>茶壶还闭着眼。拼出它的英文名字，它就会醒来，给茶杯倒一杯茶。</p>
          {completedBefore && <p className="fine">你已经陪它们喝过一次，还可以再坐下来。</p>}
          <button type="button" className="btn primary" data-testid="start" onClick={lesson.sitDown}>
            入座，打开声音
          </button>
          <p className="fine">朗读来自浏览器的英语语音，不是事先录好的声音。音乐是原创八音盒，可以单独关掉。</p>
        </section>
      )}

      {phase === 'puzzle' && (
        <div className="cloth">
          <p className="hint-line">
            中文是「{teapotLesson.hintZh}」。固定的字母不用改，只填两个空。
          </p>
          {(puzzle.feedback || puzzle.hint) && (
            <div className="toast" role="status" data-testid="feedback">
              {puzzle.feedback && <p>{puzzle.feedback}</p>}
              {puzzle.hint && (
                <p data-testid="hint">
                  <strong>{puzzle.hint}</strong>
                </p>
              )}
            </div>
          )}
          <div className="word" role="group" aria-label="单词，t 空格 a p 空格 t">
            {cells.map((cell, index) =>
              cell.kind === 'fixed' ? (
                <span key={`${cell.char}-${index}`} className="fixed" data-testid={`fixed-${index}`} data-fixed="true">
                  {cell.char}
                </span>
              ) : (
                <button
                  key={`slot-${cell.index}`}
                  type="button"
                  className={
                    'slot' +
                    (puzzle.active === cell.index ? ' is-active' : '') +
                    (puzzle.wrong && puzzle.slots[cell.index] && puzzle.slots[cell.index] !== teapotLesson.answers[cell.index]
                      ? ' is-wrong'
                      : '')
                  }
                  data-testid={`slot-${cell.index}`}
                  data-wrong={
                    puzzle.wrong && puzzle.slots[cell.index] !== teapotLesson.answers[cell.index] ? '1' : '0'
                  }
                  aria-label={`第 ${cell.index + 1} 个空${puzzle.slots[cell.index] ? `，已放入 ${puzzle.slots[cell.index]}` : '，空着'}`}
                  onClick={() => lesson.chooseSlot(cell.index)}
                >
                  {puzzle.slots[cell.index]}
                </button>
              ),
            )}
          </div>
          <div className="tray" role="group" aria-label="字母托盘">
            {puzzle.tiles.map((tile) => (
              <button
                key={tile.id}
                type="button"
                className="tile"
                data-testid={`tile-${tile.id}`}
                disabled={tile.used !== null}
                onClick={() => lesson.pressTile(tile.id)}
              >
                {tile.letter}
              </button>
            ))}
          </div>
          <div className="row">
            <button type="button" className="btn" data-testid="listen" onClick={lesson.listen}>
              听一听
            </button>
            <button type="button" className="btn" data-testid="backspace" onClick={lesson.doBackspace}>
              退格
            </button>
            <button type="button" className="btn" data-testid="clear" onClick={lesson.doClear}>
              清空
            </button>
            <button type="button" className="btn primary" data-testid="check" onClick={lesson.doCheck}>
              对一对
            </button>
          </div>
          <label className="key-slot">
            打字
            <LetterInput onLetter={lesson.typeLetter} onBackspace={lesson.doBackspace} onCheck={lesson.doCheck} />
          </label>
        </div>
      )}

      {phase === 'awaken' && !reduced && (
        <div className="stars" aria-hidden="true">
          {Array.from({ length: 12 }, (_, i) => (
            <i key={i} style={{ left: `${8 + ((i * 7) % 84)}%`, animationDelay: `${i * 0.06}s` }} />
          ))}
        </div>
      )}

      {(phase === 'awaken' || phase === 'sentence' || phase === 'dialogue' || phase === 'done') && caption && (
        <div className="caption-wrap" data-speaking={speaking ? '1' : '0'}>
          {caption.who && (
            <p className={`who who-${caption.who}`}>{caption.who === 'teapot' ? '茶壶' : caption.who === 'cup' ? '茶杯' : '旁白'}</p>
          )}
          {phase === 'awaken' && <p className="syllables">tea · pot</p>}
          <p className="en" data-testid="caption-en">
            {caption.en}
          </p>
          <p className="zh" data-testid="caption-zh">
            {caption.zh}
          </p>
          {phase === 'dialogue' && (
            <p className="leaves" aria-label={`第 ${line + 1} 句，共 ${teapotLesson.lines.length} 句`}>
              {teapotLesson.lines.map((row, index) => (
                <span key={row.id} className={index === line ? 'on' : ''} />
              ))}
            </p>
          )}
          <div className="row">
            {phase === 'awaken' && (
              <>
                <button type="button" className="btn" data-testid="replay-word" onClick={lesson.replayWord}>
                  再听一次
                </button>
                <button type="button" className="btn primary" data-testid="continue" onClick={lesson.continueStory}>
                  走进故事
                </button>
              </>
            )}
            {(phase === 'sentence' || phase === 'dialogue') && (
              <>
                {phase === 'dialogue' && (
                  <button type="button" className="btn" data-testid="back" onClick={lesson.back}>
                    上一句
                  </button>
                )}
                <button type="button" className="btn" data-testid="replay" onClick={lesson.replayLine}>
                  重听
                </button>
                <button type="button" className="btn primary" data-testid="next" onClick={lesson.next}>
                  {phase === 'sentence' ? '继续' : '下一句'}
                </button>
                <button type="button" className="btn" data-testid="skip" onClick={lesson.skipToEnd}>
                  跳到结尾
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {phase === 'done' && (
        <section className="finale">
          <p className="note" data-testid="closing-note">茶会好温暖。</p>
          <p className="eyebrow">还记得吗</p>
          <p className="recall">
            The <span className="blank">{recallOn ? 'teapot' : '_____'}</span> is on the table.
          </p>
          <div className="row">
            <button type="button" className="btn primary" data-testid="recall" onClick={lesson.placeRecall} disabled={recallOn}>
              teapot
            </button>
            <button type="button" className="btn" data-testid="replay-story" onClick={lesson.replayStory}>
              再看一遍
            </button>
            <button type="button" className="btn" data-testid="again" onClick={lesson.practiceAgain}>
              再拼一次
            </button>
          </div>
        </section>
      )}
    </div>
  )
}
