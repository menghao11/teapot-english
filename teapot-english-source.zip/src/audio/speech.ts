import { getAudio } from './engine'

export type VoiceEngine = 'unknown' | 'ready' | 'missing'

let voices: SpeechSynthesisVoice[] = []
let voiceEngine: VoiceEngine = 'unknown'
let token = 0

function englishVoices() {
  return voices.filter((voice) => voice.lang.toLowerCase().startsWith('en'))
}

export function pickEnglishVoice() {
  const list = englishVoices()
  return (
    list.find((voice) => /en-US/i.test(voice.lang) && /female|samantha|aria|jenny|google/i.test(voice.name)) ??
    list.find((voice) => /en-US/i.test(voice.lang)) ??
    list[0] ??
    null
  )
}

export function getVoiceEngine() {
  return voiceEngine
}

export function watchVoices(onChange: () => void) {
  const synth = window.speechSynthesis
  if (!synth) {
    voiceEngine = 'missing'
    onChange()
    return () => {}
  }
  const load = () => {
    voices = synth.getVoices()
    voiceEngine = englishVoices().length > 0 ? 'ready' : voices.length > 0 ? 'missing' : 'missing'
    if (voices.length === 0) voiceEngine = 'missing'
    onChange()
  }
  load()
  synth.addEventListener('voiceschanged', load)
  return () => synth.removeEventListener('voiceschanged', load)
}

export function cancelSpeech() {
  token += 1
  window.speechSynthesis?.cancel()
  getAudio().unduck()
}

export function speak(
  text: string,
  opts: { rate?: number; pitch?: number; voiceOn: boolean },
): Promise<void> {
  const mine = ++token
  window.speechSynthesis?.cancel()
  return new Promise((resolve) => {
    let settled = false
    let timer = 0
    const finish = () => {
      if (settled) return
      settled = true
      window.clearTimeout(timer)
      if (mine === token) getAudio().unduck()
      resolve()
    }
    const synth = window.speechSynthesis
    if (!opts.voiceOn || !synth) {
      finish()
      return
    }
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = 'en-US'
    utterance.rate = opts.rate ?? 0.94
    utterance.pitch = opts.pitch ?? 1.08
    const voice = pickEnglishVoice()
    getAudio().duck()
    timer = window.setTimeout(finish, Math.min(8000, 1100 + text.length * 70))
    utterance.onend = finish
    utterance.onerror = finish
    try {
      if (voice && typeof SpeechSynthesisVoice !== 'undefined' && voice instanceof SpeechSynthesisVoice) {
        utterance.voice = voice
      }
      synth.resume()
      synth.speak(utterance)
    } catch {
      finish()
    }
  })
}
