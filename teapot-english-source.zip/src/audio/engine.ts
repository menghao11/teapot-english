import bgmOggUrl from '../assets/audio/bgm_teaparty.ogg?url'
import bgmM4aUrl from '../assets/audio/bgm_teaparty.m4a?url'
import sfxOggUrl from '../assets/audio/sfx_success.ogg?url'
import sfxM4aUrl from '../assets/audio/sfx_success.m4a?url'

/**
 * Original tea-party bed from 声音王, when the files are present.
 * bgm_teaparty: music-box + plucked strings, F major, 80 BPM, 16 bars, 48.000s, 44.1kHz stereo.
 * Loop the musical body only: loopStart 0, loopEnd 48.0.
 * The M4A has about 832 AAC samples of padding at the tail — do not skip the start.
 * Success cue overlays the bed and does not restart it.
 * Duck is about 7.5 dB (gain 0.422) in 200ms, recover in 800ms.
 */

export type AudioStatus = 'idle' | 'loading' | 'ready' | 'missing'

const LOOP_END = 48
const DUCK_GAIN = 0.422
const DUCK_IN = 0.2
const DUCK_OUT = 0.8

const bundled: Record<string, string> = {
  'bgm_teaparty.ogg': bgmOggUrl,
  'bgm_teaparty.m4a': bgmM4aUrl,
  'sfx_success.ogg': sfxOggUrl,
  'sfx_success.m4a': sfxM4aUrl,
}

function bundledUrl(name: string) {
  const found = Object.entries(bundled).find(([key]) => key.endsWith('/' + name) || key.endsWith(name))
  return found?.[1]
}

async function decodeFirst(ctx: AudioContext, names: string[]) {
  const urls = names.flatMap((name) => {
    const local = bundledUrl(name)
    const pub = `${import.meta.env.BASE_URL}audio/${name}`
    return local ? [local, pub] : [pub]
  })
  for (const url of urls) {
    try {
      const res = await fetch(url)
      if (!res.ok) continue
      const copy = (await res.arrayBuffer()).slice(0)
      return await ctx.decodeAudioData(copy)
    } catch (error) {
      console.warn('Tea audio could not decode', url, error)
    }
  }
  return null
}

export class TeaAudio {
  status: AudioStatus = 'idle'
  musicOn = true
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private duckGain: GainNode | null = null
  private musicGain: GainNode | null = null
  private sfxGain: GainNode | null = null
  private bgm: AudioBuffer | null = null
  private sfx: AudioBuffer | null = null
  private source: AudioBufferSourceNode | null = null
  private startedAt = 0
  private offset = 0
  private loopEnd = LOOP_END
  private loadPromise: Promise<void> | null = null
  private listeners = new Set<() => void>()

  subscribe(listener: () => void) {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  private emit() {
    for (const listener of this.listeners) listener()
  }

  private ensure() {
    if (!this.ctx) this.ctx = new AudioContext()
    if (this.master) return
    const ctx = this.ctx
    this.master = ctx.createGain()
    this.master.gain.value = 0.95
    this.duckGain = ctx.createGain()
    this.duckGain.gain.value = 1
    this.musicGain = ctx.createGain()
    this.musicGain.gain.value = 1
    this.sfxGain = ctx.createGain()
    this.sfxGain.gain.value = 1.15
    this.musicGain.connect(this.duckGain)
    this.duckGain.connect(this.master)
    this.sfxGain.connect(this.master)
    this.master.connect(ctx.destination)
  }

  async unlock() {
    this.ensure()
    if (!this.ctx) return
    await this.ctx.resume()
    await this.load()
    if (this.musicOn) this.startMusic()
  }

  load() {
    if (this.loadPromise) return this.loadPromise
    this.loadPromise = this.loadFiles()
    return this.loadPromise
  }

  private async loadFiles() {
    this.ensure()
    if (!this.ctx) return
    this.status = 'loading'
    this.emit()
    const [bgm, sfx] = await Promise.all([
      decodeFirst(this.ctx, ['bgm_teaparty.ogg', 'bgm_teaparty.m4a']),
      decodeFirst(this.ctx, ['sfx_success.ogg', 'sfx_success.m4a']),
    ])
    this.bgm = bgm
    this.sfx = sfx
    this.status = bgm ? 'ready' : 'missing'
    this.emit()
    if (this.musicOn && this.ctx.state === 'running') this.startMusic()
  }

  setMusic(on: boolean) {
    this.musicOn = on
    if (!on) this.stopMusic()
    else if (this.ctx && this.ctx.state === 'running') this.startMusic()
  }

  startMusic() {
    if (!this.musicOn || !this.ctx || !this.bgm || !this.musicGain || this.source) return
    const src = this.ctx.createBufferSource()
    src.buffer = this.bgm
    src.loop = true
    src.loopStart = 0
    const end = this.bgm.duration >= LOOP_END ? LOOP_END : Math.max(0.05, this.bgm.duration)
    src.loopEnd = end
    this.loopEnd = end
    src.connect(this.musicGain)
    const offset = ((this.offset % end) + end) % end
    src.start(0, offset)
    this.startedAt = this.ctx.currentTime
    this.offset = offset
    this.source = src
  }

  stopMusic() {
    if (!this.source || !this.ctx) return
    const elapsed = this.ctx.currentTime - this.startedAt
    this.offset = (this.offset + elapsed) % this.loopEnd
    try {
      this.source.stop()
    } catch {
      /* already stopped */
    }
    this.source.disconnect()
    this.source = null
  }

  sfxPlays = 0
  ducking = false

  /** Success chime. Independent of the background-music toggle. Does not restart the loop. */
  playSuccess() {
    if (!this.sfx || !this.ctx || !this.sfxGain) return
    this.sfxPlays += 1
    this.emit()
    const src = this.ctx.createBufferSource()
    src.buffer = this.sfx
    src.connect(this.sfxGain)
    src.start()
    src.onended = () => src.disconnect()
  }

  duck() {
    this.ducking = true
    this.emit()
    if (!this.duckGain || !this.ctx) return
    const now = this.ctx.currentTime
    const gain = this.duckGain.gain
    gain.cancelScheduledValues(now)
    gain.setValueAtTime(gain.value, now)
    gain.linearRampToValueAtTime(DUCK_GAIN, now + DUCK_IN)
  }

  unduck() {
    this.ducking = false
    this.emit()
    if (!this.duckGain || !this.ctx) return
    const now = this.ctx.currentTime
    const gain = this.duckGain.gain
    gain.cancelScheduledValues(now)
    gain.setValueAtTime(gain.value, now)
    gain.linearRampToValueAtTime(1, now + DUCK_OUT)
  }
}

let singleton: TeaAudio | null = null

export function getAudio() {
  if (!singleton) singleton = new TeaAudio()
  return singleton
}
