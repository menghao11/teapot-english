import type { Lesson } from './types'

/**
 * One complete teapot lesson.
 * INPUT CONTRACT — fixed skeleton, not six free letters:
 * the shown word is t _ a p _ t. Only the two blanks (e, o) are editable.
 * Fixed letters are not buttons. The tray has one tile per choice, including distractors.
 * Keyboard and tiles write the same slots. Backspace frees the tile.
 */
export const teapotLesson: Lesson = {
  id: 'teapot',
  hintZh: '茶壶',
  word: 'teapot',
  pronounce: 'teapot',
  pattern: ['t', '_', 'a', 'p', '_', 't'],
  answers: ['e', 'o'],
  tiles: ['e', 'o', 'i', 'u', 'a', 'r'],
  sentence: {
    en: 'The teapot is on the table.',
    zh: '茶壶在桌子上。',
    hold: 2400,
  },
  lines: [
    {
      id: 'greet',
      speaker: 'teapot',
      en: 'Hello, little cup!',
      zh: '你好，小茶杯！',
      action: 'greet',
      hold: 2000,
      pitch: 1.14,
    },
    {
      id: 'near',
      speaker: 'cup',
      en: 'Hello! Is it tea time?',
      zh: '你好！到喝茶时间了吗？',
      action: 'near',
      hold: 2100,
      pitch: 1.28,
    },
    {
      id: 'pour',
      speaker: 'teapot',
      en: 'Yes! Here is your tea.',
      zh: '是呀！这是你的茶。',
      action: 'pour',
      hold: 2600,
      pitch: 1.12,
    },
    {
      id: 'warm',
      speaker: 'cup',
      en: 'Thank you! I feel warm.',
      zh: '谢谢！我觉得暖暖的。',
      action: 'warm',
      hold: 2000,
      pitch: 1.26,
    },
    {
      id: 'approach',
      speaker: 'teapot',
      en: 'Tea is better with a friend.',
      zh: '和朋友一起喝茶更好。',
      action: 'approach',
      hold: 2200,
      pitch: 1.1,
    },
    {
      id: 'friends',
      speaker: 'cup',
      en: "That's you!",
      zh: '你就是我的朋友呀！',
      action: 'friends',
      hold: 2300,
      pitch: 1.3,
    },
  ],
}

export function patternCells(lesson: Lesson) {
  let blank = 0
  return lesson.pattern.map((ch) => {
    if (ch === '_') {
      const index = blank
      blank += 1
      return { kind: 'slot' as const, index }
    }
    return { kind: 'fixed' as const, char: ch }
  })
}
