import type { Phase } from './types'
import { teapotLesson } from './teapotLesson'

export interface SceneState {
  mode: Phase
  teapotX: number
  turn: number
  nod: boolean
  tilt: number
  lidHop: boolean
  lidWiggle: boolean
  hearts: boolean
  lit: boolean
  cupVisible: boolean
  cupX: number
  hop: boolean
  /** 0 empty, 0.7 after the pour line. Hop is forced off once this is above 0. */
  fill: number
  pour: boolean
  warm: boolean
  sway: boolean
  blink: boolean
  look: boolean
}

function base(phase: Phase): SceneState {
  return {
    mode: phase,
    teapotX: phase === 'sentence' || phase === 'done' ? 0.06 : 0.2,
    turn: 0,
    nod: false,
    tilt: 0,
    lidHop: phase === 'awaken',
    lidWiggle: false,
    hearts: phase === 'awaken',
    lit: phase !== 'invite' && phase !== 'puzzle',
    cupVisible: false,
    cupX: -1.2,
    hop: false,
    fill: 0,
    pour: false,
    warm: false,
    sway: false,
    blink: false,
    look: false,
  }
}

function applyDialogue(phase: Phase, index: number, playing: boolean): SceneState {
  const s = base(phase)
  s.lit = true
  const last = teapotLesson.lines.length - 1
  const clamped = Math.max(0, Math.min(last, index))
  for (let i = 0; i <= clamped; i += 1) {
    const current = playing && i === clamped
    const action = teapotLesson.lines[i]?.action
    if (action === 'greet') {
      s.cupVisible = true
      s.turn = 0.62
      s.nod = current
      s.hop = current
      s.cupX = current ? -0.86 : -0.48
    } else if (action === 'near') {
      s.cupVisible = true
      s.hop = false
      s.cupX = -0.42
      s.turn = 0.5
      s.nod = false
      s.blink = current
    } else if (action === 'pour') {
      s.hop = false
      s.fill = 0.7
      s.pour = current
      s.tilt = current ? 0.58 : 0
      s.turn = 0.55
      s.blink = false
    } else if (action === 'warm') {
      s.pour = false
      s.tilt = 0
      s.fill = 0.7
      s.hop = false
      s.warm = true
      s.sway = current
      s.turn = 0.42
    } else if (action === 'approach') {
      s.teapotX = 0.02
      s.hearts = current
      s.sway = false
      s.warm = true
      s.fill = 0.7
      s.hop = false
      s.tilt = 0
      s.pour = false
    } else if (action === 'friends') {
      s.lidWiggle = current
      s.look = true
      s.turn = 0.2
      s.blink = current
      s.hearts = false
      s.teapotX = -0.02
      s.cupX = -0.34
      s.warm = true
      s.fill = 0.7
      s.hop = false
      s.sway = false
      s.pour = false
      s.tilt = 0
      s.turn = 0.35
    }
  }
  if (s.fill > 0) s.hop = false
  return s
}

export function deriveScene(phase: Phase, line: number): SceneState {
  if (phase === 'whirl') {
    const s = base(phase)
    s.turn = 0.4
    s.tilt = 0.32
    s.lit = true
    return s
  }
  if (phase === 'sentence') {
    const s = base(phase)
    s.teapotX = 0.02
    s.lit = true
    return s
  }
  if (phase === 'dialogue') return applyDialogue(phase, line, true)
  if (phase === 'done') {
    const s = applyDialogue(phase, teapotLesson.lines.length - 1, false)
    s.look = true
    s.warm = true
    s.fill = 0.7
    s.hop = false
    return s
  }
  return base(phase)
}
