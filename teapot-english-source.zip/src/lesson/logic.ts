import type { Lesson, PuzzleState } from './types'

export function createPuzzle(lesson: Lesson): PuzzleState {
  const seen = new Map<string, number>()
  return {
    slots: lesson.answers.map(() => ''),
    tiles: lesson.tiles.map((letter) => {
      const n = (seen.get(letter) ?? 0) + 1
      seen.set(letter, n)
      const dup = lesson.tiles.filter((item) => item === letter).length > 1
      return { id: dup ? `${letter}-${n}` : letter, letter, used: null }
    }),
    active: 0,
    attempts: 0,
    feedback: null,
    hint: null,
    wrong: false,
    solved: false,
  }
}

function withPlacement(puzzle: PuzzleState, tileId: string): PuzzleState {
  const tile = puzzle.tiles.find((item) => item.id === tileId)
  if (!tile || tile.used !== null) return puzzle
  let index = puzzle.slots[puzzle.active] === '' ? puzzle.active : puzzle.slots.findIndex((slot) => slot === '')
  if (index < 0) index = puzzle.active
  const slots = puzzle.slots.slice()
  slots[index] = tile.letter
  const tiles = puzzle.tiles.map((item) => {
    if (item.used === index) return { ...item, used: null }
    if (item.id === tileId) return { ...item, used: index }
    return item
  })
  const nextEmpty = slots.findIndex((slot) => slot === '')
  return {
    ...puzzle,
    slots,
    tiles,
    active: nextEmpty === -1 ? index : nextEmpty,
    feedback: null,
    wrong: false,
  }
}

export function placeTile(puzzle: PuzzleState, tileId: string): PuzzleState {
  if (puzzle.solved) return puzzle
  return withPlacement(puzzle, tileId)
}

export function placeLetter(puzzle: PuzzleState, letter: string): PuzzleState {
  if (puzzle.solved) return puzzle
  const tile = puzzle.tiles.find((item) => item.letter === letter && item.used === null)
  if (!tile) {
    return { ...puzzle, feedback: '托盘里没有这个字母。', wrong: false }
  }
  return withPlacement(puzzle, tile.id)
}

export function selectSlot(puzzle: PuzzleState, index: number): PuzzleState {
  if (puzzle.solved) return puzzle
  if (index < 0 || index >= puzzle.slots.length) return puzzle
  return { ...puzzle, active: index }
}

export function backspace(puzzle: PuzzleState): PuzzleState {
  if (puzzle.solved) return puzzle
  let index = puzzle.slots[puzzle.active] ? puzzle.active : -1
  if (index < 0) {
    for (let i = puzzle.slots.length - 1; i >= 0; i -= 1) {
      if (puzzle.slots[i]) {
        index = i
        break
      }
    }
  }
  if (index < 0) return puzzle
  const slots = puzzle.slots.slice()
  slots[index] = ''
  const tiles = puzzle.tiles.map((item) => (item.used === index ? { ...item, used: null } : item))
  return { ...puzzle, slots, tiles, active: index, feedback: null, wrong: false }
}

export function clearLetters(puzzle: PuzzleState): PuzzleState {
  if (puzzle.solved) return puzzle
  return {
    ...puzzle,
    slots: puzzle.slots.map(() => ''),
    tiles: puzzle.tiles.map((item) => ({ ...item, used: null })),
    active: 0,
    feedback: null,
    wrong: false,
  }
}

export function checkPuzzle(lesson: Lesson, puzzle: PuzzleState): { correct: boolean; puzzle: PuzzleState } {
  if (puzzle.solved) return { correct: true, puzzle }
  if (puzzle.slots.some((slot) => slot === '')) {
    return {
      correct: false,
      puzzle: { ...puzzle, feedback: '两个空都放上字母，再轻轻对一下。', wrong: false },
    }
  }
  const correct = puzzle.slots.every((slot, index) => slot === lesson.answers[index])
  if (correct) {
    return {
      correct: true,
      puzzle: { ...puzzle, solved: true, feedback: null, wrong: false },
    }
  }
  const attempts = puzzle.attempts + 1
  let hint = puzzle.hint
  if (attempts >= 2) {
    const idx = lesson.answers.findIndex((answer, index) => puzzle.slots[index] !== answer)
    if (idx >= 0) hint = `再看看第 ${idx + 1} 个空，字母是 ${lesson.answers[idx]}`
  }
  return {
    correct: false,
    puzzle: {
      ...puzzle,
      attempts,
      hint,
      wrong: true,
      feedback: '还不对。字母先留在桌上，慢慢想。',
    },
  }
}
