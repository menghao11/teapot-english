/** Data contract for later lessons. Replace or append a Lesson; the runner and scene read these fields only. */

export type SpeakerId = 'teapot' | 'cup' | 'narrator'

/**
 * Scene verbs the 3D stage understands.
 * New lines can reuse these. A brand-new verb needs a pose in sceneState.ts.
 */
export type SceneAction = 'greet' | 'near' | 'pour' | 'warm' | 'approach' | 'friends'

export interface DialogueLine {
  id: string
  speaker: Exclude<SpeakerId, 'narrator'>
  en: string
  zh: string
  action: SceneAction
  /** Pause after speech before auto-advance. Buttons never wait on this. */
  hold: number
  pitch: number
}

export interface Lesson {
  id: string
  hintZh: string
  word: string
  /** Spoken by itself before the example sentence. */
  pronounce: string
  /** '_' marks an editable blank. Other characters are fixed and not controls. */
  pattern: string[]
  /** Answers for blanks, in order. */
  answers: string[]
  /** Tray letters. One tile each. Duplicates would be separate entries. */
  tiles: string[]
  sentence: { en: string; zh: string; hold: number }
  lines: DialogueLine[]
}

export interface Tile {
  id: string
  letter: string
  /** Slot index currently holding this tile, or null if it is on the tray. */
  used: number | null
}

export interface PuzzleState {
  slots: string[]
  tiles: Tile[]
  active: number
  attempts: number
  feedback: string | null
  hint: string | null
  wrong: boolean
  solved: boolean
}

export type Phase =
  | 'invite'
  | 'puzzle'
  | 'awaken'
  | 'whirl'
  | 'sentence'
  | 'dialogue'
  | 'done'

export interface Caption {
  en: string
  zh: string
  who: SpeakerId | null
}
