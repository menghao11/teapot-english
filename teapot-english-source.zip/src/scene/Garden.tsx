import { useMemo } from 'react'
import * as THREE from 'three'
import backdropUrl from '../assets/garden/garden-backdrop.jpg'

/** Painted garden behind the 3D table. No characters are in this picture. */
export function Garden() {
  const map = useMemo(() => {
    const tex = new THREE.TextureLoader().load(backdropUrl)
    tex.colorSpace = THREE.SRGBColorSpace
    tex.anisotropy = 8
    return tex
  }, [])

  return (
    <group>
      <mesh position={[0.35, 2.05, -3.35]}>
        <planeGeometry args={[12.4, 6.6]} />
        <meshBasicMaterial map={map} toneMapped={false} fog={false} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, 0.2]} receiveShadow>
        <circleGeometry args={[8, 32]} />
        <meshStandardMaterial color="#c5d6a4" roughness={1} />
      </mesh>
    </group>
  )
}
