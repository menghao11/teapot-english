import { useMemo, useRef } from 'react'
import type { RefObject } from 'react'
import { useFrame } from '@react-three/fiber'
import type { Mesh, Object3D, SpriteMaterial } from 'three'
import * as THREE from 'three'
import { useLesson } from '../state/LessonContext'
import type { Phase } from '../lesson/types'
import type { SceneState } from '../lesson/sceneState'
import { Garden } from './Garden'
import teapotUrl from '../assets/art/teapot.png'
import teacupUrl from '../assets/art/teacup.png'

const _up = new THREE.Vector3(0, 1, 0)
const _dir = new THREE.Vector3()
const _from = new THREE.Vector3()
const _to = new THREE.Vector3()
const _local = new THREE.Vector3()
const _feet = new THREE.Vector3()

const TABLE_Y = 0.64
const TEAPOT_H = 1.28
const TEAPOT_W = TEAPOT_H * (675 / 747)
const CUP_H = TEAPOT_H * 0.7
const CUP_W = CUP_H * (489 / 585)

const CAM: Record<Phase, { pos: [number, number, number]; look: [number, number, number] }> = {
  invite: { pos: [0.08, 1.22, 2.55], look: [0.05, 0.95, -0.2] },
  puzzle: { pos: [0.04, 1.18, 2.35], look: [0.08, 1.0, 0] },
  awaken: { pos: [0.1, 1.12, 2.05], look: [0.12, 1.05, 0.02] },
  whirl: { pos: [0.02, 1.14, 1.9], look: [0.0, 0.95, -0.05] },
  sentence: { pos: [0.06, 1.34, 2.7], look: [-0.02, 0.78, -0.15] },
  dialogue: { pos: [0.0, 1.2, 2.25], look: [-0.06, 0.95, 0.02] },
  done: { pos: [0.0, 1.22, 2.35], look: [-0.04, 0.92, 0.0] },
}

function loadSprite(url: string) {
  const tex = new THREE.TextureLoader().load(url)
  tex.colorSpace = THREE.SRGBColorSpace
  return tex
}

export function TeaWorld() {
  const { scene, speaking, speaker, phase, reduced } = useLesson()
  const tip = useRef<Object3D>(null)
  const rim = useRef<Object3D>(null)
  const look = useRef(new THREE.Vector3(...CAM.invite.look))
  const table = useMemo(() => tableTexture(), [])

  useFrame((state, dt) => {
    const cam = CAM[phase]
    const px = reduced ? 0 : THREE.MathUtils.clamp(state.pointer.x, -1, 1) * 0.03
    const py = reduced ? 0 : THREE.MathUtils.clamp(state.pointer.y, -1, 1) * 0.015
    const lambda = reduced ? 18 : 2.2
    const camera = state.camera
    camera.position.x = THREE.MathUtils.damp(camera.position.x, cam.pos[0] + px, lambda, dt)
    camera.position.y = THREE.MathUtils.damp(camera.position.y, cam.pos[1] + py, lambda, dt)
    camera.position.z = THREE.MathUtils.damp(camera.position.z, cam.pos[2], lambda, dt)
    look.current.x = THREE.MathUtils.damp(look.current.x, cam.look[0], lambda, dt)
    look.current.y = THREE.MathUtils.damp(look.current.y, cam.look[1], lambda, dt)
    look.current.z = THREE.MathUtils.damp(look.current.z, cam.look[2], lambda, dt)
    camera.lookAt(look.current)
  })

  return (
    <>
      <color attach="background" args={['#f6e2c4']} />
      <hemisphereLight args={['#ffe6c8', '#c5d2a4', 0.9]} />
      <ambientLight intensity={0.55} color="#fff6ea" />
      <directionalLight position={[2.4, 4.5, 2.2]} intensity={0.85} color="#ffd7ae" />
      <Garden />
      <SoftTable map={table} />
      <PaintedCast scene={scene} speaking={speaking} speaker={speaker} reduced={reduced} tip={tip} rim={rim} />
      <TeaStream active={scene.pour} from={tip} to={rim} reduced={reduced} />
    </>
  )
}

function PaintedCast({
  scene,
  speaking,
  speaker,
  reduced,
  tip,
  rim,
}: {
  scene: SceneState
  speaking: boolean
  speaker: string | null
  reduced: boolean
  tip: RefObject<Object3D | null>
  rim: RefObject<Object3D | null>
}) {
  const teapotMap = useMemo(() => loadSprite(teapotUrl), [])
  const cupMap = useMemo(() => loadSprite(teacupUrl), [])
  const shadowMap = useMemo(() => softShadowTexture(), [])
  const teaMap = useMemo(() => teaDiscTexture(), [])
  const teapot = useRef<THREE.Sprite>(null)
  const cup = useRef<THREE.Sprite>(null)
  const tea = useRef<THREE.Sprite>(null)
  const teapotShadow = useRef<Mesh>(null)
  const cupShadow = useRef<Mesh>(null)
  const poseRef = useRef(scene)
  const speakRef = useRef(speaking)
  const whoRef = useRef(speaker)
  const reducedRef = useRef(reduced)
  poseRef.current = scene
  speakRef.current = speaking
  whoRef.current = speaker
  reducedRef.current = reduced

  useFrame(({ clock }, dt) => {
    const p = poseRef.current
    const calm = reducedRef.current
    const time = clock.elapsedTime
    const asleep = p.mode === 'invite' || p.mode === 'puzzle'
    const breathe = !calm && asleep ? 1 + Math.sin(time * 1.5) * 0.015 : 1
    let hop = 0
    let squash = 1
    if (p.lidHop && !calm) {
      const phaseT = (time % 1.25) / 1.25
      hop = Math.abs(Math.sin(phaseT * Math.PI * 2)) * 0.09
      squash = 1 - hop * 0.8
    } else if (p.hop && p.fill <= 0 && !calm) {
      hop = Math.abs(Math.sin(time * 8)) * 0.06
      squash = 1 - hop
    }
    const pour = p.pour && !calm ? 0.32 : 0
    const nod = speakRef.current && whoRef.current === 'teapot' && !calm ? Math.sin(time * 6.5) * 0.035 : 0
    const lean = pour + nod
    const teapotX = p.teapotX + 0.22
    const pot = teapot.current
    if (pot) {
      pot.position.x = THREE.MathUtils.damp(pot.position.x, teapotX, calm ? 20 : 3, dt)
      pot.position.y = TABLE_Y + (p.hop && p.fill <= 0 ? hop : p.lidHop ? hop : 0)
      pot.scale.set(TEAPOT_W * (2 - squash), TEAPOT_H * squash * breathe, 1)
      const mat = pot.material as SpriteMaterial
      mat.rotation = lean
      mat.color.set(p.lit ? '#ffffff' : '#e4d3bf')
    }
    if (teapotShadow.current) {
      teapotShadow.current.position.x = pot?.position.x ?? teapotX
      teapotShadow.current.scale.x = 1 - hop * 2
    }
    const cupHop = p.hop && p.fill <= 0 && !calm ? Math.abs(Math.sin(time * 8 + 0.5)) * 0.045 : 0
    const sway = p.sway && p.fill > 0 && !calm ? Math.sin(time * 2.1) * 0.02 : 0
    const cupTalk = speakRef.current && whoRef.current === 'cup' && !calm ? Math.sin(time * 7) * 0.03 : 0
    const cupX = p.cupVisible ? p.cupX - 0.22 + sway : -1.7
    const mug = cup.current
    if (mug) {
      mug.position.x = THREE.MathUtils.damp(mug.position.x, cupX, calm ? 24 : 3.1, dt)
      mug.position.y = TABLE_Y + (p.fill > 0 ? 0 : cupHop)
      mug.visible = p.cupVisible || mug.position.x > -1.4
      const cs = p.fill > 0 || calm ? 1 : 1 - cupHop * 0.8
      mug.scale.set(CUP_W * (2 - cs), CUP_H * cs, 1)
      ;(mug.material as SpriteMaterial).rotation = cupTalk
    }
    if (cupShadow.current) {
      cupShadow.current.position.x = mug?.position.x ?? cupX
      cupShadow.current.visible = mug?.visible ?? false
    }
    const teaSprite = tea.current
    if (teaSprite && mug) {
      teaSprite.visible = p.fill > 0.05 && mug.visible
      teaSprite.position.x = mug.position.x + 0.02
      teaSprite.position.y = mug.position.y + CUP_H * 0.9
      teaSprite.scale.set(0.22 + p.fill * 0.08, 0.07, 1)
    }
    const potY = pot?.position.y ?? TABLE_Y
    const mugY = mug?.position.y ?? TABLE_Y
    placeAnchor(tip.current, pot?.position.x ?? teapotX, potY, -0.4 * TEAPOT_W, 0.72 * TEAPOT_H, lean)
    placeAnchor(rim.current, mug?.position.x ?? cupX, mugY, 0.0, 0.94 * CUP_H, cupTalk)
  })

  return (
    <group>
      <sprite ref={teapot} position={[0.35, TABLE_Y, 0.06]} scale={[TEAPOT_W, TEAPOT_H, 1]} center={[0.5, 0]} renderOrder={3}>
        <spriteMaterial map={teapotMap} transparent depthWrite={false} toneMapped={false} />
      </sprite>
      <sprite ref={cup} position={[-1.5, TABLE_Y, 0.18]} scale={[CUP_W, CUP_H, 1]} center={[0.5, 0]} renderOrder={2}>
        <spriteMaterial map={cupMap} transparent depthWrite={false} toneMapped={false} />
      </sprite>
      <sprite ref={tea} position={[0, 2, 0.22]} visible={false} center={[0.5, 0.5]} renderOrder={4}>
        <spriteMaterial map={teaMap} transparent depthWrite={false} toneMapped={false} />
      </sprite>
      <mesh ref={teapotShadow} rotation={[-Math.PI / 2, 0, 0]} position={[0.35, TABLE_Y + 0.008, 0.06]}>
        <planeGeometry args={[0.72, 0.26]} />
        <meshBasicMaterial map={shadowMap} transparent depthWrite={false} />
      </mesh>
      <mesh ref={cupShadow} rotation={[-Math.PI / 2, 0, 0]} position={[-0.55, TABLE_Y + 0.008, 0.18]} visible={false}>
        <planeGeometry args={[0.62, 0.22]} />
        <meshBasicMaterial map={shadowMap} transparent depthWrite={false} />
      </mesh>
      <object3D ref={tip} />
      <object3D ref={rim} />
    </group>
  )
}

function placeAnchor(
  node: Object3D | null,
  feetX: number,
  feetY: number,
  localX: number,
  localY: number,
  rot: number,
) {
  if (!node) return
  _local.set(localX, localY, 0.04).applyAxisAngle(_up.set(0, 0, 1), rot)
  _feet.set(feetX, feetY, 0.12)
  node.position.copy(_feet).add(_local)
}

function SoftTable({ map }: { map: THREE.Texture }) {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0.05, TABLE_Y - 0.01, 0.55]} receiveShadow>
      <planeGeometry args={[3.4, 2.15]} />
      <meshBasicMaterial map={map} transparent toneMapped={false} />
    </mesh>
  )
}

function TeaStream({
  active,
  from,
  to,
  reduced,
}: {
  active: boolean
  from: RefObject<Object3D | null>
  to: RefObject<Object3D | null>
  reduced: boolean
}) {
  const beam = useRef<Mesh>(null)
  const drops = useRef<Array<Mesh | null>>([])
  const activeRef = useRef(active)
  const reducedRef = useRef(reduced)
  activeRef.current = active
  reducedRef.current = reduced
  useFrame(({ clock }) => {
    const mesh = beam.current
    if (!mesh || !from.current || !to.current) return
    const show = activeRef.current
    mesh.visible = show
    if (!show) {
      drops.current.forEach((drop) => {
        if (drop) drop.visible = false
      })
      return
    }
    from.current.getWorldPosition(_from)
    to.current.getWorldPosition(_to)
    _to.y -= 0.02
    _dir.copy(_to).sub(_from)
    const len = Math.max(0.05, _dir.length())
    mesh.position.copy(_from).addScaledVector(_dir, 0.5)
    mesh.scale.set(1, len, 1)
    mesh.quaternion.setFromUnitVectors(_up.set(0, 1, 0), _dir.clone().normalize())
    const count = drops.current.length
    for (let i = 0; i < count; i += 1) {
      const drop = drops.current[i]
      if (!drop) continue
      const speed = reducedRef.current ? i / count : (i / count + clock.elapsedTime * 1.2) % 1
      drop.visible = true
      drop.position.lerpVectors(_from, _to, speed)
      drop.position.y += Math.sin(speed * Math.PI) * 0.03
    }
  })
  return (
    <group renderOrder={4}>
      <mesh ref={beam} visible={false}>
        <cylinderGeometry args={[0.012, 0.018, 1, 8]} />
        <meshBasicMaterial color="#c4843a" transparent opacity={0.82} depthWrite={false} />
      </mesh>
      {Array.from({ length: 7 }, (_, i) => (
        <mesh
          key={i}
          visible={false}
          ref={(node) => {
            drops.current[i] = node
          }}
        >
          <sphereGeometry args={[0.018, 8, 8]} />
          <meshBasicMaterial color="#e0a15a" transparent opacity={0.9} depthWrite={false} />
        </mesh>
      ))}
    </group>
  )
}

function tableTexture() {
  const canvas = document.createElement('canvas')
  canvas.width = 512
  canvas.height = 512
  const g = canvas.getContext('2d')
  if (!g) return new THREE.CanvasTexture(canvas)
  g.clearRect(0, 0, 512, 512)
  roundRect(g, 36, 70, 440, 360, 28)
  g.fillStyle = '#e7c49a'
  g.fill()
  g.globalAlpha = 0.18
  for (let i = 0; i < 18; i += 1) {
    g.strokeStyle = '#a56b3c'
    g.beginPath()
    const y = 90 + i * 18
    g.moveTo(50, y)
    g.bezierCurveTo(180, y + 4, 320, y - 3, 460, y + 2)
    g.stroke()
  }
  g.globalAlpha = 1
  roundRect(g, 96, 120, 320, 250, 18)
  g.fillStyle = '#f6ecdf'
  g.fill()
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  return tex
}

function roundRect(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath()
  g.moveTo(x + r, y)
  g.arcTo(x + w, y, x + w, y + h, r)
  g.arcTo(x + w, y + h, x, y + h, r)
  g.arcTo(x, y + h, x, y, r)
  g.arcTo(x, y, x + w, y, r)
  g.closePath()
}

function softShadowTexture() {
  const canvas = document.createElement('canvas')
  canvas.width = 128
  canvas.height = 64
  const g = canvas.getContext('2d')
  if (!g) return new THREE.CanvasTexture(canvas)
  const grd = g.createRadialGradient(64, 32, 4, 64, 32, 60)
  grd.addColorStop(0, 'rgba(90, 58, 36, 0.35)')
  grd.addColorStop(1, 'rgba(90, 58, 36, 0)')
  g.fillStyle = grd
  g.fillRect(0, 0, 128, 64)
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  return tex
}

function teaDiscTexture() {
  const canvas = document.createElement('canvas')
  canvas.width = 64
  canvas.height = 32
  const g = canvas.getContext('2d')
  if (!g) return new THREE.CanvasTexture(canvas)
  const grd = g.createRadialGradient(32, 16, 2, 32, 16, 28)
  grd.addColorStop(0, 'rgba(232, 176, 92, 0.95)')
  grd.addColorStop(1, 'rgba(152, 95, 36, 0.15)')
  g.fillStyle = grd
  g.beginPath()
  g.ellipse(32, 16, 26, 12, 0, 0, Math.PI * 2)
  g.fill()
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  return tex
}
